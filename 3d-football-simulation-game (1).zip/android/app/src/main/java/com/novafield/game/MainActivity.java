package com.novafield.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * NOVA Field 26 — local, full-screen WebGL game shell.
 * The game is bundled at assets/www/index.html; there are no remote dependencies.
 */
public class MainActivity extends Activity {
    private WebView webView;
    private GyroBridge gyroBridge;
    private long lastBackPress = 0L;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(attributes);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        hideSystemUi();

        WebView.setWebContentsDebuggingEnabled(false);
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        webView.setBackgroundColor(Color.rgb(7, 18, 23));
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLongClickable(false);
        webView.setHapticFeedbackEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setOffscreenPreRaster(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(false);
        }

        gyroBridge = new GyroBridge(this);
        webView.addJavascriptInterface(gyroBridge, "AndroidSensors");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The release is self-contained. Never navigate away from local assets.
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        webView.setOnLongClickListener(view -> true);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (gyroBridge != null) gyroBridge.stop();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (gyroBridge != null) gyroBridge.stop();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidSensors");
            webView.destroy();
        }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 1600) {
            super.onBackPressed();
            return;
        }
        lastBackPress = now;
        if (webView != null) {
            webView.evaluateJavascript(
                "window.dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape',bubbles:true}))",
                null
            );
        }
        Toast.makeText(this, "Match paused. Press back again to exit.", Toast.LENGTH_SHORT).show();
    }

    /**
     * Native sensor bridge. It supplies reliable yaw/pitch readings inside WebView;
     * the web camera only orbits its focus and never rotates simulation coordinates.
     */
    private static final class GyroBridge implements SensorEventListener {
        private final SensorManager sensorManager;
        private final Sensor rotationSensor;
        private float[] rotationMatrix = new float[9];
        private float[] orientation = new float[3];
        private volatile float azimuth = 0f;
        private volatile float pitch = 0f;
        private boolean running = false;

        GyroBridge(Context context) {
            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
            Sensor chosen = sensorManager != null
                ? sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
                : null;
            if (chosen == null && sensorManager != null) {
                chosen = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            }
            rotationSensor = chosen;
        }

        @JavascriptInterface
        public boolean isSupported() {
            return rotationSensor != null;
        }

        @JavascriptInterface
        public void start() {
            if (sensorManager == null || rotationSensor == null || running) return;
            sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
            running = true;
        }

        @JavascriptInterface
        public void stop() {
            if (sensorManager == null) return;
            sensorManager.unregisterListener(this);
            running = false;
        }

        @JavascriptInterface
        public float getAzimuth() {
            return azimuth;
        }

        @JavascriptInterface
        public float getPitch() {
            return pitch;
        }

        @Override
        public void onSensorChanged(SensorEvent event) {
            float[] values = event.values.clone();
            SensorManager.getRotationMatrixFromVector(rotationMatrix, values);
            SensorManager.getOrientation(rotationMatrix, orientation);
            azimuth = (float) Math.toDegrees(orientation[0]);
            pitch = (float) Math.toDegrees(orientation[1]);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            // Not used: the camera applies its own smoothing.
        }
    }
}
