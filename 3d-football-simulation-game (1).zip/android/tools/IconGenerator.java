import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Generates the shipped launcher icon at every Android density. */
public final class IconGenerator {
    private static void draw(int size, File output) throws Exception {
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g.setColor(new Color(16, 31, 31));
        g.fill(new RoundRectangle2D.Float(0, 0, size, size, size * 0.18f, size * 0.18f));
        g.setPaint(new GradientPaint(0, 0, new Color(35, 76, 66), size, size, new Color(4, 20, 23)));
        g.fill(new RoundRectangle2D.Float(size * 0.035f, size * 0.035f, size * 0.93f, size * 0.93f, size * 0.16f, size * 0.16f));

        g.setColor(new Color(201, 244, 106, 30));
        for (int i = 1; i < 7; i++) {
            g.fillRect((int)(size * 0.08f), (int)(size * (0.12f + i * 0.12f)), (int)(size * 0.84f), Math.max(1, size / 100));
        }

        Path2D shield = new Path2D.Float();
        shield.moveTo(size * 0.22f, size * 0.18f);
        shield.lineTo(size * 0.5f, size * 0.1f);
        shield.lineTo(size * 0.78f, size * 0.18f);
        shield.lineTo(size * 0.78f, size * 0.54f);
        shield.curveTo(size * 0.77f, size * 0.72f, size * 0.62f, size * 0.83f, size * 0.5f, size * 0.9f);
        shield.curveTo(size * 0.38f, size * 0.83f, size * 0.23f, size * 0.72f, size * 0.22f, size * 0.54f);
        shield.closePath();
        g.setColor(new Color(7, 24, 24));
        g.fill(shield);
        g.setStroke(new BasicStroke(size * 0.017f));
        g.setColor(new Color(201, 244, 106));
        g.draw(shield);

        g.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, Math.round(size * 0.44f)));
        FontMetrics metrics = g.getFontMetrics();
        String letter = "N";
        int textX = (size - metrics.stringWidth(letter)) / 2;
        int textY = Math.round(size * 0.59f);
        g.setColor(new Color(0, 0, 0, 90));
        g.drawString(letter, textX + Math.max(1, size / 80), textY + Math.max(1, size / 80));
        g.setColor(new Color(201, 244, 106));
        g.drawString(letter, textX, textY);

        g.setColor(new Color(234, 242, 226));
        g.setFont(new Font("SansSerif", Font.BOLD, Math.round(size * 0.09f)));
        FontMetrics small = g.getFontMetrics();
        String caption = "26";
        g.drawString(caption, (size - small.stringWidth(caption)) / 2, Math.round(size * 0.76f));

        g.setColor(new Color(201, 244, 106));
        g.fillOval(Math.round(size * 0.46f), Math.round(size * 0.81f), Math.round(size * 0.08f), Math.round(size * 0.08f));
        g.setColor(new Color(11, 22, 21));
        g.fillOval(Math.round(size * 0.48f), Math.round(size * 0.826f), Math.round(size * 0.04f), Math.round(size * 0.04f));

        g.dispose();
        output.getParentFile().mkdirs();
        ImageIO.write(image, "png", output);
    }

    public static void main(String[] args) throws Exception {
        String root = args.length > 0 ? args[0] : "android/app/src/main/res";
        Object[][] densities = {
            {"mdpi", 48}, {"hdpi", 72}, {"xhdpi", 96}, {"xxhdpi", 144}, {"xxxhdpi", 192}
        };
        for (Object[] density : densities) {
            int size = (Integer) density[1];
            draw(size, new File(root + "/mipmap-" + density[0] + "/ic_launcher.png"));
        }
        draw(432, new File("android/release/icon-432.png"));
        System.out.println("Android launcher icons generated.");
    }
}
