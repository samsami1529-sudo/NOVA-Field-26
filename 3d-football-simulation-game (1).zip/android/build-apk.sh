#!/usr/bin/env bash
# Reproducible, signed NOVA Field 26 Android release build.
# Requirements: JDK 17, Android SDK platform 35, build-tools 35.0.0, zip.
# Environment overrides: JAVA_HOME, ANDROID_HOME, ANDROID_SDK_ROOT.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ANDROID_PROJECT="$ROOT/android"
APP="$ANDROID_PROJECT/app/src/main"
BUILD="$ANDROID_PROJECT/build"
DIST="$ROOT/dist"
TOOLS_ROOT="${ANDROID_TOOLS_ROOT:-/tmp/android-tools}"
JAVA_HOME="${JAVA_HOME:-$TOOLS_ROOT/jdk}"
ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$TOOLS_ROOT/sdk}}"
BUILD_TOOLS="$ANDROID_HOME/build-tools/35.0.0"
PLATFORM="$ANDROID_HOME/platforms/android-35/android.jar"
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$BUILD_TOOLS:$PATH"

APP_NAME="NOVA-Field-26-arm64"
VERSION_CODE="${NOVA_VERSION_CODE:-10100}"
VERSION_NAME="${NOVA_VERSION_NAME:-1.1.0}"
KEYSTORE="$ANDROID_PROJECT/release/nova-release.jks"
KEY_ALIAS="${NOVA_KEY_ALIAS:-novafield}"
KEY_PASS="${NOVA_KEY_PASS:-NovaField26Release!}"
KEY_DNAME="CN=NOVA Field 26, OU=Games, O=NOVA Interactive, L=London, C=GB"

for required in "$JAVA_HOME/bin/java" "$BUILD_TOOLS/aapt2" "$BUILD_TOOLS/d8" "$BUILD_TOOLS/zipalign" "$BUILD_TOOLS/apksigner" "$PLATFORM"; do
  if [[ ! -e "$required" ]]; then
    echo "Missing Android build dependency: $required" >&2
    echo "Install JDK 17 plus SDK platform 35 and build-tools 35.0.0." >&2
    exit 2
  fi
done

if [[ ! -f "$DIST/index.html" ]]; then
  echo "Missing $DIST/index.html. Run 'npm run build' first." >&2
  exit 3
fi

echo "[1/8] Bundling the latest web build into Android assets"
rm -rf "$APP/assets/www"
mkdir -p "$APP/assets/www"
cp -R "$DIST/." "$APP/assets/www/"
rm -f "$APP/assets/www/"*.apk "$APP/assets/www/"*.apk.sha256
rm -rf "$BUILD"
mkdir -p "$BUILD/compiled" "$BUILD/classes" "$BUILD/gen" "$BUILD/dex" "$ANDROID_PROJECT/release"

if [[ ! -f "$KEYSTORE" ]]; then
  echo "[2/8] Creating release signing identity"
  keytool -genkeypair -v \
    -keystore "$KEYSTORE" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA -keysize 4096 -validity 10000 \
    -storepass "$KEY_PASS" -keypass "$KEY_PASS" \
    -dname "$KEY_DNAME" >/dev/null
else
  echo "[2/8] Using existing release signing identity"
fi

echo "[3/8] Compiling Android resources"
"$BUILD_TOOLS/aapt2" compile --dir "$APP/res" -o "$BUILD/compiled/resources.zip"
"$BUILD_TOOLS/aapt2" link \
  -o "$BUILD/unsigned.apk" \
  -I "$PLATFORM" \
  --manifest "$APP/AndroidManifest.xml" \
  --java "$BUILD/gen" \
  --min-sdk-version 24 \
  --target-sdk-version 35 \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  --auto-add-overlay \
  "$BUILD/compiled/resources.zip"

echo "[4/8] Compiling and dexing the native shell"
find "$APP/java" "$BUILD/gen" -name '*.java' > "$BUILD/sources.txt"
javac -source 8 -target 8 -encoding UTF-8 \
  -classpath "$PLATFORM" \
  -d "$BUILD/classes" \
  @"$BUILD/sources.txt"
"$BUILD_TOOLS/d8" --release --min-api 24 \
  --lib "$PLATFORM" \
  --output "$BUILD/dex" \
  $(find "$BUILD/classes" -name '*.class')

echo "[5/8] Packaging assets, Java classes and WebGL game"
cp "$BUILD/dex/classes.dex" "$BUILD/classes.dex"
cd "$BUILD"
zip -q -9 unsigned.apk classes.dex
cd "$APP"
zip -q -9 -r "$BUILD/unsigned.apk" assets

echo "[6/8] Aligning and signing (APK Signature Scheme v2 + v3)"
"$BUILD_TOOLS/zipalign" -f -p 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk"
"$BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias "$KEY_ALIAS" \
  --ks-pass "pass:$KEY_PASS" \
  --key-pass "pass:$KEY_PASS" \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --out "$BUILD/$APP_NAME.apk" \
  "$BUILD/aligned.apk"

echo "[7/8] Verifying signature, manifest and ZIP integrity"
"$BUILD_TOOLS/apksigner" verify --verbose --print-certs "$BUILD/$APP_NAME.apk"
"$BUILD_TOOLS/aapt2" dump badging "$BUILD/$APP_NAME.apk" > "$BUILD/badging.txt"
unzip -t "$BUILD/$APP_NAME.apk" > "$BUILD/unzip-test.txt"
grep -q "index.html" <(unzip -l "$BUILD/$APP_NAME.apk") || { echo "Game assets missing from APK" >&2; exit 4; }
grep -q "package: name='com.novafield.game'" "$BUILD/badging.txt"
grep -q "minSdkVersion:'24'" "$BUILD/badging.txt"
grep -q "targetSdkVersion:'35'" "$BUILD/badging.txt"
grep -q "application-label:'NOVA Field 26'" "$BUILD/badging.txt"
SKBITS="$("$JAVA_HOME/bin/keytool" -list -v -keystore "$KEYSTORE" -alias "$KEY_ALIAS" -storepass "$KEY_PASS" | grep 'Signature algorithm name' | head -1 | sed 's/^ *//')"
echo "Signing certificate: $SKBITS"

echo "[8/8] Publishing the APK beside the web build"
mkdir -p "$ROOT/public" "$ANDROID_PROJECT/release"
cp "$BUILD/$APP_NAME.apk" "$ROOT/public/$APP_NAME.apk"
cp "$BUILD/$APP_NAME.apk" "$ANDROID_PROJECT/release/$APP_NAME.apk"
sha256sum "$ROOT/public/$APP_NAME.apk" | tee "$ROOT/public/$APP_NAME.apk.sha256"
ls -lh "$ROOT/public/$APP_NAME.apk"
echo "SIGNED RELEASE READY: public/$APP_NAME.apk ($(stat -c%s "$ROOT/public/$APP_NAME.apk") bytes)"
