# NOVA Field 26 — Android release

## Deliverable
`public/NOVA-Field-26-arm64.apk` (also `dist/NOVA-Field-26-arm64.apk`)
SHA-256: `fbb78415ad86429dbbc18fc257c7afa87fb190c63eba0e321b46ad7577e337ae`

- Package: `com.novafield.game`
- Version: 1.1.0 (10100)
- Built with Google SDK 35 / build-tools 35.0.0 / Temurin JDK 17
- Signed with APK Signature Scheme v2 + v3 (RSA 4096, SHA384withRSA)
- Launcher icon, landscape game activity, edge-to-edge immersive shell
- No permissions requested; no INTERNET permission; all assets bundled locally
- minSdk 24 (Android 7.0), targetSdk 35 (Android 15)
- No native `.so` libraries: the shell is portable Java/WebView, so it runs on
  arm64-v8a devices as required as well as 32-bit ARM and x86_64.

## Install
1. Copy the APK to an Android device (7.0+).
2. Allow installs from this source when prompted.
3. Open **NOVA Field 26**; the game starts in sensor landscape.
4. Gyroscope is opt-in: Settings -> Phone Gyroscope -> Enable gyroscope.

## Rebuild
Prerequisites: JDK 17, Android SDK platform 35 and build-tools 35.0.0, plus `zip`.
Set `JAVA_HOME` and `ANDROID_HOME`, then:

```bash
npm run build
bash android/build-apk.sh
```

The API 35 manifest is authoritative; the legacy `uses-sdk` attributes were
removed so the resource compiler's min/target flags are used consistently.
The script verifies the signature, manifest, ZIP integrity and web-asset parity
before copying the APK to `public/` and `dist/`.

## Test status (honest)
Verified in this environment:
- APK actually compiled, zipaligned and signed (not source-only).
- `apksigner verify` passes with v2/v3; `unzip -t` passes.
- `aapt2` confirms package id, minSdk 24, targetSdk 35, landscape feature,
  launcher activity and label.
- The bundled `assets/www/index.html` is checksum-identical to `dist/index.html`.
- The web build inside the APK was exercised in headless Chromium at desktop,
  Android landscape and Android portrait sizes: WebGL rendered, no page errors,
  quality preset changes, zoom and synthetic orientation input worked.

Not verified here:
- On-device launch in an emulator or physical phone. This sandbox exposes no
  `/dev/kvm`, has 2 GB RAM, and no Android emulator image; WebView hardware
  WebGL and the native rotation-vector bridge could therefore not be executed
  on Android itself. Do not treat the APK as device-tested until you install it.
