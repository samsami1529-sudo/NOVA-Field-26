import { memo, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import type { MutableRefObject } from "react";
import { PlayerAvatar } from "./Player";
import { readSnapshot, tickMatch } from "./simulation";
import { Stadium } from "./Stadium";
import type { CameraStyle, GraphicsQuality, InputState, MatchSnapshot, MatchState, Player, TeamDefinition, TimeOfDay, Weather } from "./types";

const OFFICIALS: TeamDefinition = {
  id: "officials",
  name: "Match Officials",
  short: "REF",
  city: "NOVA",
  colors: { kit: "#27312f", trim: "#e2b95f", shorts: "#232c29", socks: "#29332e", keeper: "#27312f", keeperTrim: "#e2b95f" },
};

type MatchSceneProps = {
  matchRef: MutableRefObject<MatchState>;
  inputRef: MutableRefObject<InputState>;
  teams: [TeamDefinition, TeamDefinition];
  weather: Weather;
  timeOfDay: TimeOfDay;
  paused: boolean;
  cameraStyle: CameraStyle;
  cameraZoom: number;
  quality: GraphicsQuality;
  gyroEnabled: boolean;
  gyroYawRef: MutableRefObject<number>;
  gyroPitchRef: MutableRefObject<number>;
  onSnapshot: (snapshot: MatchSnapshot) => void;
};

function makeBallTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const context = canvas.getContext("2d");
  const texture = new THREE.CanvasTexture(canvas);
  if (!context) return texture;
  context.fillStyle = "#eee9d9";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.strokeStyle = "#c6c1b6";
  context.lineWidth = 5;
  for (let row = 0; row < 4; row += 1) {
    for (let column = 0; column < 9; column += 1) {
      const x = column * 128 + (row % 2) * 64;
      const y = row * 128 + 8;
      context.beginPath();
      for (let side = 0; side < 6; side += 1) {
        const angle = (Math.PI / 3) * side + Math.PI / 6;
        const px = x + Math.cos(angle) * 34;
        const py = y + Math.sin(angle) * 34;
        if (side === 0) context.moveTo(px, py);
        else context.lineTo(px, py);
      }
      context.closePath();
      context.fillStyle = (row + column) % 4 === 0 ? "#172324" : "#f6f4e9";
      context.fill();
      context.stroke();
    }
  }
  for (let index = 0; index < 70; index += 1) {
    const x = (index * 157) % canvas.width;
    const y = (index * 71) % canvas.height;
    context.fillStyle = "rgba(28, 36, 34, 0.045)";
    context.fillRect(x, y, 55, 2);
  }
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

const MatchBall = memo(function MatchBall({ matchRef }: { matchRef: MutableRefObject<MatchState> }) {
  const ballRef = useRef<THREE.Mesh>(null);
  const texture = useMemo(makeBallTexture, []);
  const shadowMaterial = useMemo(() => new THREE.MeshBasicMaterial({ color: "#06110d", transparent: true, opacity: 0.27, depthWrite: false }), []);
  const shadow = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (!ballRef.current || !shadow.current) return;
    const ball = matchRef.current.ball;
    ballRef.current.position.set(ball.x, ball.y, ball.z);
    ballRef.current.rotation.x += ball.vz * delta * 1.4;
    ballRef.current.rotation.z -= ball.vx * delta * 1.4;
    const heightFade = THREE.MathUtils.clamp(1 - (ball.y - 0.23) * 0.19, 0.28, 1);
    shadow.current.position.set(ball.x, 0.065, ball.z);
    shadow.current.scale.setScalar(0.75 + heightFade * 0.25);
    shadowMaterial.opacity = 0.26 * heightFade;
  });

  return (
    <group>
      <mesh ref={shadow} rotation={[-Math.PI / 2, 0, 0]} material={shadowMaterial}>
        <circleGeometry args={[0.4, 20]} />
      </mesh>
      <mesh ref={ballRef} castShadow receiveShadow>
        <sphereGeometry args={[0.235, 32, 24]} />
        <meshStandardMaterial map={texture} color="#ffffff" roughness={0.48} metalness={0.025} />
      </mesh>
    </group>
  );
});

function OfficialActor({ matchRef, lane, quality }: { matchRef: MutableRefObject<MatchState>; lane: -1 | 0 | 1; quality: GraphicsQuality }) {
  const player = useMemo<Player>(() => ({
    id: `official-${lane}`,
    team: 0,
    number: lane === 0 ? 4 : 2,
    name: lane === 0 ? "Match official" : "Assistant official",
    role: "REF",
    x: lane === 0 ? -5 : 0,
    z: lane * 35.2,
    baseX: 0,
    baseZ: lane * 35.2,
    vx: 0,
    vz: 0,
    angle: 0,
    stamina: 100,
    height: 0.95,
    build: 0.91,
    skin: lane === 1 ? "#b77d5e" : "#deb18d",
    hair: "#27221f",
    hairStyle: lane === 0 ? 1 : 2,
    keeper: false,
    visible: true,
    actionUntil: 0,
  }), [lane]);

  useFrame((_, delta) => {
    const game = matchRef.current;
    player.visible = game.mode !== "PENALTIES";
    const targetX = lane === 0 ? game.ball.x * 0.46 - 3 : THREE.MathUtils.clamp(game.ball.x + lane * 1.5, -48, 48);
    const targetZ = lane === 0 ? game.ball.z * 0.42 + 2 : lane * 35.1;
    const dx = targetX - player.x;
    const dz = targetZ - player.z;
    const distance = Math.hypot(dx, dz);
    const speed = Math.min(lane === 0 ? 5.2 : 6.5, distance * 2.8);
    const pace = Math.min(1, delta * 5.2);
    player.vx += ((distance > 0.02 ? dx / distance * speed : 0) - player.vx) * pace;
    player.vz += ((distance > 0.02 ? dz / distance * speed : 0) - player.vz) * pace;
    player.x += player.vx * delta;
    player.z += player.vz * delta;
    if (Math.hypot(player.vx, player.vz) > 0.2) player.angle = Math.atan2(player.vx, player.vz);
  });

  return <PlayerAvatar player={player} team={OFFICIALS} selected={false} quality={quality} />;
}

const ContactShadows = memo(function ContactShadows({ matchRef }: { matchRef: MutableRefObject<MatchState> }) {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const material = useMemo(() => new THREE.MeshBasicMaterial({ color: "#061310", transparent: true, opacity: 0.34, depthWrite: false }), []);

  useFrame(() => {
    if (!mesh.current) return;
    const game = matchRef.current;
    let index = 0;
    game.players.forEach((player) => {
      if (!player.visible) return;
      dummy.position.set(player.x, 0.061, player.z);
      dummy.rotation.set(-Math.PI / 2, 0, 0);
      dummy.scale.set(0.46, 0.32, 1);
      dummy.updateMatrix();
      mesh.current!.setMatrixAt(index, dummy.matrix);
      index += 1;
    });
    mesh.current.count = index;
    mesh.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={mesh} args={[undefined, material, 22]} frustumCulled={false} renderOrder={2}>
      <circleGeometry args={[1, 16]} />
    </instancedMesh>
  );
});

const MatchRunner = memo(function MatchRunner({ matchRef, inputRef, paused, onSnapshot }: Pick<MatchSceneProps, "matchRef" | "inputRef" | "paused" | "onSnapshot">) {
  const report = useRef(onSnapshot);
  const reportTimer = useRef(0);
  report.current = onSnapshot;

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.04);
    if (!paused) tickMatch(matchRef.current, inputRef.current, dt);
    reportTimer.current += dt;
    if (reportTimer.current >= 0.22) {
      report.current(readSnapshot(matchRef.current));
      reportTimer.current = 0;
    }
  });

  return null;
});

const BroadcastCamera = memo(function BroadcastCamera({
  matchRef,
  cameraStyle,
  cameraZoom,
  gyroEnabled,
  gyroYawRef,
  gyroPitchRef,
}: Pick<MatchSceneProps, "matchRef" | "cameraStyle" | "cameraZoom" | "gyroEnabled" | "gyroYawRef" | "gyroPitchRef">) {
  const { camera, size } = useThree();
  const desired = useMemo(() => new THREE.Vector3(), []);
  const focus = useMemo(() => new THREE.Vector3(0, 0.8, 0), []);
  const targetFocus = useMemo(() => new THREE.Vector3(), []);
  const orbit = useRef(0);
  const initialized = useRef(false);
  const smoothedHeight = useRef(11.2);
  const smoothedZoom = useRef(cameraZoom);
  const fov = useRef(48);

  useFrame((_, rawDelta) => {
    const game = matchRef.current;
    const delta = Math.min(rawDelta, 1 / 30);
    const width = Math.max(1, size.width);
    const height = Math.max(1, size.height);
    const aspect = width / height;
    const portrait = aspect < 1.05;
    const selected = game.players.find((player) => player.id === game.selectedId);
    const isPenalty = game.mode === "PENALTIES";
    const penaltyDirection = game.penaltyTeam === 0 ? 1 : -1;

    // Centre the game on the ball, the controlled player and the nearby block of play.
    let focusX: number;
    let focusZ: number;
    if (isPenalty) {
      focusX = penaltyDirection * 46.1;
      focusZ = game.ball.z * 0.34;
    } else {
      const nearby = game.players.filter((player) => !player.keeper && Math.hypot(player.x - game.ball.x, player.z - game.ball.z) < 24);
      const nearbyX = nearby.length ? nearby.reduce((sum, player) => sum + player.x, 0) / nearby.length : game.ball.x;
      const nearbyZ = nearby.length ? nearby.reduce((sum, player) => sum + player.z, 0) / nearby.length : game.ball.z;
      focusX = game.ball.x * 0.62 + (selected?.x ?? game.ball.x) * 0.2 + nearbyX * 0.18;
      focusZ = game.ball.z * 0.62 + (selected?.z ?? game.ball.z) * 0.2 + nearbyZ * 0.18;
      focusX += THREE.MathUtils.clamp(game.ball.vx * 0.1, -1.6, 1.6);
      focusZ += THREE.MathUtils.clamp(game.ball.vz * 0.1, -1.6, 1.6);
      focusX = THREE.MathUtils.clamp(focusX, -47, 47);
      focusZ = THREE.MathUtils.clamp(focusZ, -30, 30);
    }
    targetFocus.set(focusX, isPenalty ? 0.9 : 1.05, focusZ);

    if (!initialized.current) {
      focus.copy(targetFocus);
      smoothedHeight.current = isPenalty ? 7.1 : 10.8;
      camera.position.set(
        focusX - (isPenalty ? penaltyDirection * 12 : 13.1),
        smoothedHeight.current,
        focusZ + (isPenalty ? 3.4 : 7.6),
      );
      camera.lookAt(focusX, 0.9, focusZ);
      initialized.current = true;
    }

    // Two-stage damping: large pans move progressively and small corrections settle.
    const focusEase = 1 - Math.exp(-delta * (isPenalty ? 2.1 : 2.9));
    focus.lerp(targetFocus, focusEase);

    const zoomTarget = THREE.MathUtils.clamp(cameraZoom, 0.72, 1.55);
    smoothedZoom.current += (zoomTarget - smoothedZoom.current) * (1 - Math.exp(-delta * 4.2));
    const zoomFactor = smoothedZoom.current;

    const tactical = cameraStyle === "TACTICAL";
    const wantedHeight = isPenalty
      ? 7.05 + (zoomFactor - 1) * 1.7
      : (tactical ? 11.4 : 10.7) * (0.87 + zoomFactor * 0.13) * (portrait ? 1.16 : 1);
    const wantedOrbit = gyroEnabled ? THREE.MathUtils.clamp(gyroYawRef.current, -1.45, 1.45) : 0;
    const orbitEase = 1 - Math.exp(-delta * 3.3);
    orbit.current += (wantedOrbit - orbit.current) * orbitEase;
    const tilt = gyroEnabled ? THREE.MathUtils.clamp(gyroPitchRef.current, -0.3, 0.32) : 0;

    smoothedHeight.current += (wantedHeight - smoothedHeight.current) * (1 - Math.exp(-delta * 3.4));
    const behind = (isPenalty ? 11.4 : tactical ? 11.1 : 11.9) * (0.86 + zoomFactor * 0.14) * (portrait ? 1.08 : 1);
    const sideline = (isPenalty ? 3.2 : tactical ? 8.8 : 7.2) * (0.88 + zoomFactor * 0.12);
    const sin = Math.sin(orbit.current);
    const cos = Math.cos(orbit.current);
    const baseX = isPenalty ? -penaltyDirection * behind : -behind;
    const rotatedX = baseX * cos - sideline * sin;
    const rotatedZ = baseX * sin + sideline * cos;
    const sideClamp = isPenalty ? 9.5 : 38;
    desired.set(
      THREE.MathUtils.clamp(focus.x + rotatedX, -61, 61),
      smoothedHeight.current + tilt * 7,
      THREE.MathUtils.clamp(focus.z + rotatedZ, -sideClamp, sideClamp),
    );

    // Frame the ball rather than staring at one player's boots.
    const lookAtBall = isPenalty ? focus.z * 0.25 : THREE.MathUtils.clamp(game.ball.z * 0.08, -1, 1);
    const cameraEase = 1 - Math.exp(-delta * 4.4);
    camera.position.lerp(desired, cameraEase);
    camera.up.set(0, 1, 0);
    camera.lookAt(focus.x + (isPenalty ? penaltyDirection * 3.8 : 1.7), isPenalty ? 1.3 : 0.55, focus.z + lookAtBall);

    const wantedFov = isPenalty ? (portrait ? 52 : 44) : (portrait ? 60 : 52);
    fov.current += (wantedFov - fov.current) * (1 - Math.exp(-delta * 2.4));
    if (camera instanceof THREE.PerspectiveCamera && Math.abs(camera.fov - fov.current) > 0.02) {
      camera.fov = fov.current;
      camera.updateProjectionMatrix();
    }
  });

  return null;
});

export function MatchScene({
  matchRef,
  inputRef,
  teams,
  weather,
  timeOfDay,
  paused,
  cameraStyle,
  cameraZoom,
  quality,
  gyroEnabled,
  gyroYawRef,
  gyroPitchRef,
  onSnapshot,
}: MatchSceneProps) {
  return (
    <>
      <Stadium weather={weather} timeOfDay={timeOfDay} quality={quality} />
      <BroadcastCamera
        matchRef={matchRef}
        cameraStyle={cameraStyle}
        cameraZoom={cameraZoom}
        gyroEnabled={gyroEnabled}
        gyroYawRef={gyroYawRef}
        gyroPitchRef={gyroPitchRef}
      />
      <MatchRunner matchRef={matchRef} inputRef={inputRef} paused={paused} onSnapshot={onSnapshot} />
      {matchRef.current.players.map((player) => (
        <PlayerAvatar key={player.id} player={player} team={teams[player.team]} selected={player.id === matchRef.current.selectedId} quality={quality} />
      ))}
      <ContactShadows matchRef={matchRef} />
      <OfficialActor matchRef={matchRef} lane={0} quality={quality} />
      <OfficialActor matchRef={matchRef} lane={-1} quality={quality} />
      <OfficialActor matchRef={matchRef} lane={1} quality={quality} />
      <MatchBall matchRef={matchRef} />
    </>
  );
}