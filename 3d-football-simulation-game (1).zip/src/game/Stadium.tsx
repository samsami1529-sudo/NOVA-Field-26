import { memo, useLayoutEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { GraphicsQuality, TimeOfDay, Weather } from "./types";

const FIELD_LENGTH = 104;
const FIELD_WIDTH = 68;
const CROWD_COLORS = ["#d2d8cc", "#798d8b", "#b7a887", "#1d3941", "#748d70", "#a34e43", "#293d53", "#e4dfce"];

function makeTexture(width: number, height: number, draw: (context: CanvasRenderingContext2D) => void) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) return new THREE.CanvasTexture(canvas);
  draw(context);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function makePitchTexture() {
  return makeTexture(2048, 1360, (context) => {
    const width = context.canvas.width;
    const height = context.canvas.height;
    context.fillStyle = "#327a4e";
    context.fillRect(0, 0, width, height);
    const bands = 12;
    for (let band = 0; band < bands; band += 1) {
      const stripeWidth = width / bands;
      context.fillStyle = band % 2 === 0 ? "rgba(182, 214, 145, 0.085)" : "rgba(4, 45, 29, 0.075)";
      context.fillRect(band * stripeWidth, 0, stripeWidth, height);
    }
    for (let i = 0; i < 18000; i += 1) {
      const x = (i * 7919) % width;
      const y = (i * 3571) % height;
      context.fillStyle = i % 3 === 0 ? "rgba(225, 238, 183, 0.09)" : "rgba(7, 44, 25, 0.08)";
      context.fillRect(x, y, 2, 7 + (i % 10));
    }
    const vignette = context.createRadialGradient(width / 2, height / 2, width * 0.08, width / 2, height / 2, width * 0.68);
    vignette.addColorStop(0, "rgba(178, 211, 122, 0.06)");
    vignette.addColorStop(1, "rgba(4, 24, 18, 0.25)");
    context.fillStyle = vignette;
    context.fillRect(0, 0, width, height);
  });
}

function makeBoardTexture() {
  return makeTexture(1024, 160, (context) => {
    const gradient = context.createLinearGradient(0, 0, 0, 160);
    gradient.addColorStop(0, "#213a38");
    gradient.addColorStop(1, "#102321");
    context.fillStyle = gradient;
    context.fillRect(0, 0, 1024, 160);
    context.fillStyle = "#c9f46a";
    context.fillRect(0, 0, 7, 160);
    context.fillRect(0, 151, 1024, 3);
    context.font = "700 66px Arial, sans-serif";
    context.letterSpacing = "10px";
    context.fillStyle = "#eff2dd";
    context.fillText("NOVA", 44, 103);
    context.font = "500 24px Arial, sans-serif";
    context.letterSpacing = "5px";
    context.fillStyle = "#a9bcaa";
    context.fillText("PLAY BEAUTIFULLY", 396, 100);
    context.fillStyle = "rgba(255,255,255,0.11)";
    context.fillRect(780, 0, 2, 160);
    context.font = "700 24px Arial, sans-serif";
    context.letterSpacing = "3px";
    context.fillStyle = "#c9f46a";
    context.fillText("NIGHT SERIES", 813, 95);
  });
}

function makeScoreTexture() {
  return makeTexture(768, 320, (context) => {
    const gradient = context.createLinearGradient(0, 0, 768, 320);
    gradient.addColorStop(0, "#19312f");
    gradient.addColorStop(1, "#081718");
    context.fillStyle = gradient;
    context.fillRect(0, 0, 768, 320);
    context.strokeStyle = "rgba(200, 244, 106, 0.72)";
    context.lineWidth = 4;
    context.strokeRect(12, 12, 744, 296);
    context.textAlign = "center";
    context.font = "700 33px Arial, sans-serif";
    context.letterSpacing = "8px";
    context.fillStyle = "#c9f46a";
    context.fillText("NOVA ARENA", 384, 90);
    context.font = "700 90px Arial, sans-serif";
    context.letterSpacing = "4px";
    context.fillStyle = "#f1f3e9";
    context.fillText("THE 90", 384, 202);
    context.font = "500 22px Arial, sans-serif";
    context.letterSpacing = "6px";
    context.fillStyle = "#a2b3a9";
    context.fillText("NIGHT FOOTBALL", 384, 265);
  });
}

function PitchLines() {
  const white = "#e7eadb";
  const line = (x: number, z: number, lengthX: number, lengthZ: number, key: string) => (
    <mesh key={key} position={[x, 0.062, z]} receiveShadow>
      <boxGeometry args={[lengthX, 0.045, lengthZ]} />
      <meshStandardMaterial color={white} roughness={0.85} metalness={0.02} />
    </mesh>
  );
  const arcGeometry = useMemo(() => {
    const points = Array.from({ length: 70 }, (_, index) => {
      const angle = (index / 69) * Math.PI;
      return new THREE.Vector3(Math.cos(angle) * 9.15, 0.064, Math.sin(angle) * 9.15);
    });
    return new THREE.BufferGeometry().setFromPoints(points);
  }, []);

  return (
    <group>
      {line(0, -FIELD_WIDTH / 2, FIELD_LENGTH, 0.13, "touch-n")}
      {line(0, FIELD_WIDTH / 2, FIELD_LENGTH, 0.13, "touch-s")}
      {line(-FIELD_LENGTH / 2, 0, 0.13, FIELD_WIDTH, "goal-w")}
      {line(FIELD_LENGTH / 2, 0, 0.13, FIELD_WIDTH, "goal-e")}
      {line(0, 0, 0.12, FIELD_WIDTH, "half")}
      {[[-41.5, 0], [41.5, 0]].map(([x], index) => (
        <group key={`box-${index}`}>
          {line(x, -20.15, 0.12, 0.12, `box-top-${index}`)}
          {line(x, 20.15, 0.12, 0.12, `box-bottom-${index}`)}
          {line(x, 0, 0.12, 40.3, `box-front-${index}`)}
          {line(index === 0 ? -47.5 : 47.5, -9.16, 0.12, 0.12, `six-top-${index}`)}
          {line(index === 0 ? -47.5 : 47.5, 9.16, 0.12, 0.12, `six-bottom-${index}`)}
          {line(index === 0 ? -47.5 : 47.5, 0, 0.12, 18.32, `six-front-${index}`)}
        </group>
      ))}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.067, 0]}>
        <ringGeometry args={[9.12, 9.25, 128]} />
        <meshStandardMaterial color={white} roughness={0.88} side={THREE.DoubleSide} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.068, 0]}>
        <circleGeometry args={[0.22, 32]} />
        <meshStandardMaterial color={white} roughness={0.8} />
      </mesh>
      {[-41, 41].map((x) => (
        <mesh key={`spot-${x}`} rotation={[-Math.PI / 2, 0, 0]} position={[x, 0.07, 0]}>
          <circleGeometry args={[0.18, 24]} />
          <meshStandardMaterial color={white} />
        </mesh>
      ))}
      <lineSegments geometry={arcGeometry} position={[-41.5, 0, 0]} rotation={[0, Math.PI, 0]}>
        <lineBasicMaterial color={white} />
      </lineSegments>
      <lineSegments geometry={arcGeometry} position={[41.5, 0, 0]}>
        <lineBasicMaterial color={white} />
      </lineSegments>
      {[-1, 1].map((side) =>
        [-1, 1].map((corner) => (
          <mesh key={`corner-${side}-${corner}`} rotation={[-Math.PI / 2, 0, 0]} position={[side * 51.8, 0.066, corner * 33.8]}>
            <ringGeometry args={[1.1, 1.2, 28, 1, corner < 0 ? 0 : Math.PI / 2, Math.PI / 2]} />
            <meshStandardMaterial color={white} side={THREE.DoubleSide} />
          </mesh>
        )),
      )}
    </group>
  );
}

function Pitch({ weather, quality }: { weather: Weather; quality: GraphicsQuality }) {
  const texture = useMemo(makePitchTexture, []);
  const bladeMaterial = useMemo(() => new THREE.MeshStandardMaterial({ color: "#b6d48c", roughness: 0.9, side: THREE.DoubleSide }), []);
  const grassGeometry = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute([
      -0.04, 0, 0, 0.04, 0, 0, 0, 0.13, 0,
      0, 0.13, 0, 0.04, 0, 0, 0.02, 0, 0.065,
    ], 3));
    geometry.setIndex([0, 1, 2, 3, 4, 5]);
    geometry.computeVertexNormals();
    return geometry;
  }, []);
  const bladeColors = useMemo(() => {
    let seed = 4817;
    const random = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    const bladeCount = quality === "PERFORMANCE" ? 1000 : quality === "BALANCED" ? 3600 : 7000;
    return Array.from({ length: bladeCount }, () => ({
      x: (random() - 0.5) * (FIELD_LENGTH - 1),
      z: (random() - 0.5) * (FIELD_WIDTH - 1),
      rotation: random() * Math.PI,
      scale: 0.45 + random() * 0.72,
      color: new THREE.Color().setHSL(0.31 + random() * 0.035, 0.25 + random() * 0.25, 0.34 + random() * 0.11),
    }));
  }, [quality]);
  const bladesRef = useRef<THREE.InstancedMesh>(null);

  useLayoutEffect(() => {
    const mesh = bladesRef.current;
    if (!mesh) return;
    const object = new THREE.Object3D();
    bladeColors.forEach((blade, index) => {
      object.position.set(blade.x, 0.055, blade.z);
      object.rotation.set(0, blade.rotation, 0);
      object.scale.setScalar(blade.scale);
      object.updateMatrix();
      mesh.setMatrixAt(index, object.matrix);
      mesh.setColorAt(index, blade.color);
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [bladeColors]);

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[FIELD_LENGTH + 1.6, FIELD_WIDTH + 1.6]} />
        <meshStandardMaterial color="#173727" roughness={1} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.015, 0]} receiveShadow>
        <planeGeometry args={[FIELD_LENGTH, FIELD_WIDTH]} />
        <meshStandardMaterial map={texture} roughness={weather === "RAIN" ? 0.66 : 0.93} metalness={weather === "RAIN" ? 0.08 : 0.01} />
      </mesh>
      <instancedMesh ref={bladesRef} args={[grassGeometry, bladeMaterial, bladeColors.length]} castShadow={false} frustumCulled={false} />
      <PitchLines />
    </group>
  );
}

function Goal({ side }: { side: -1 | 1 }) {
  const netGeometry = useMemo(() => {
    const values: number[] = [];
    const rearX = side * 2.7;
    const postZ = [-3.66, 3.66];
    const add = (a: [number, number, number], b: [number, number, number]) => values.push(...a, ...b);
    [0, rearX].forEach((x) => {
      for (let row = 0; row <= 8; row += 1) {
        const y = 0.08 + row * 0.29;
        add([x, y, -3.66], [x, y, 3.66]);
      }
      for (let col = 0; col <= 12; col += 1) {
        const z = -3.66 + col * 0.61;
        add([x, 0.08, z], [x, 2.4, z]);
      }
    });
    postZ.forEach((z) => {
      for (let row = 0; row <= 8; row += 1) {
        const y = 0.08 + row * 0.29;
        add([0, y, z], [rearX, y, z]);
      }
    });
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(values, 3));
    return geometry;
  }, [side]);

  return (
    <group position={[side * 52.15, 0, 0]}>
      <mesh position={[0, 1.21, -3.66]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 2.42, 12]} />
        <meshStandardMaterial color="#f2f1e6" metalness={0.28} roughness={0.26} />
      </mesh>
      <mesh position={[0, 1.21, 3.66]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 2.42, 12]} />
        <meshStandardMaterial color="#f2f1e6" metalness={0.28} roughness={0.26} />
      </mesh>
      <mesh position={[0, 2.42, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 7.34, 12]} />
        <meshStandardMaterial color="#f2f1e6" metalness={0.28} roughness={0.26} />
      </mesh>
      <lineSegments geometry={netGeometry}>
        <lineBasicMaterial color="#d8e3d8" transparent opacity={0.5} />
      </lineSegments>
      <mesh position={[side * 1.36, 1.2, 0]}>
        <boxGeometry args={[2.75, 0.035, 7.28]} />
        <meshBasicMaterial color="#d6eadb" transparent opacity={0.09} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

function AdBoards() {
  const texture = useMemo(makeBoardTexture, []);
  const boardMaterial = useMemo(() => new THREE.MeshStandardMaterial({ map: texture, roughness: 0.62, metalness: 0.18, emissive: "#233a2b", emissiveIntensity: 0.24 }), [texture]);
  const rails = [];
  for (let index = 0; index < 12; index += 1) {
    const x = -50 + index * 9.1;
    rails.push(<mesh key={`long-${index}`} position={[x, 0.72, -35.6]} material={boardMaterial}><boxGeometry args={[8.95, 0.92, 0.3]} /></mesh>);
    rails.push(<mesh key={`long-front-${index}`} position={[x, 0.72, 35.6]} rotation={[0, Math.PI, 0]} material={boardMaterial}><boxGeometry args={[8.95, 0.92, 0.3]} /></mesh>);
  }
  for (let index = 0; index < 7; index += 1) {
    const z = -27 + index * 9;
    rails.push(<mesh key={`end-${index}`} position={[-53.6, 0.72, z]} rotation={[0, Math.PI / 2, 0]} material={boardMaterial}><boxGeometry args={[8.8, 0.92, 0.3]} /></mesh>);
    rails.push(<mesh key={`end-front-${index}`} position={[53.6, 0.72, z]} rotation={[0, -Math.PI / 2, 0]} material={boardMaterial}><boxGeometry args={[8.8, 0.92, 0.3]} /></mesh>);
  }
  return <group>{rails}</group>;
}

type CrowdSpot = { x: number; y: number; z: number; rotation: number; shade: number; scale: number };

function createCrowd(density: number) {
  const spots: CrowdSpot[] = [];
  let seed = 727;
  const random = () => {
    seed = (seed * 48271) % 2147483647;
    return seed / 2147483647;
  };
  const stride = density >= 0.99 ? 1 : density >= 0.6 ? 2 : 3;
  for (const side of [-1, 1]) {
    for (let row = 0; row < 14; row += 1) {
      const z = side * (41.6 + row * 0.96);
      const y = 3.2 + row * 0.52;
      for (let seat = 0; seat < 156; seat += stride) {
        spots.push({ x: -66 + seat * 0.85, y, z, rotation: side === 1 ? Math.PI : 0, shade: Math.floor(random() * CROWD_COLORS.length), scale: 0.83 + random() * 0.3 });
      }
    }
    for (let row = 0; row < 12; row += 1) {
      const z = side * (59.2 + row * 1.08);
      const y = 12.4 + row * 0.68;
      for (let seat = 0; seat < 150; seat += stride) {
        spots.push({ x: -64 + seat * 0.86, y, z, rotation: side === 1 ? Math.PI : 0, shade: Math.floor(random() * CROWD_COLORS.length), scale: 0.86 + random() * 0.26 });
      }
    }
  }
  for (const side of [-1, 1]) {
    for (let row = 0; row < 13; row += 1) {
      const x = side * (54.5 + row * 0.95);
      const y = 3.1 + row * 0.53;
      for (let seat = 0; seat < 88; seat += stride) {
        spots.push({ x, y, z: -39 + seat * 0.9, rotation: side === 1 ? -Math.PI / 2 : Math.PI / 2, shade: Math.floor(random() * CROWD_COLORS.length), scale: 0.84 + random() * 0.29 });
      }
    }
    for (let row = 0; row < 11; row += 1) {
      const x = side * (69.2 + row * 1.05);
      const y = 11.9 + row * 0.7;
      for (let seat = 0; seat < 86; seat += stride) {
        spots.push({ x, y, z: -38 + seat * 0.9, rotation: side === 1 ? -Math.PI / 2 : Math.PI / 2, shade: Math.floor(random() * CROWD_COLORS.length), scale: 0.85 + random() * 0.27 });
      }
    }
  }
  return spots;
}

function Crowd({ quality }: { quality: GraphicsQuality }) {
  const spots = useMemo(() => createCrowd(quality === "PERFORMANCE" ? 0.34 : quality === "BALANCED" ? 0.62 : 1), [quality]);
  const animatedIndices = useMemo(() => {
    const every = quality === "PERFORMANCE" ? 151 : quality === "BALANCED" ? 73 : 41;
    return spots.map((_, index) => index).filter((index) => index % every === 0);
  }, [spots, quality]);
  const bodies = useRef<THREE.InstancedMesh>(null);
  const heads = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const bodyGeometry = useMemo(() => new THREE.CapsuleGeometry(0.19, 0.4, 3, 5), []);
  const headGeometry = useMemo(() => new THREE.SphereGeometry(0.145, 7, 6), []);
  const bodyMaterial = useMemo(() => new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.91, vertexColors: true }), []);
  const headMaterial = useMemo(() => new THREE.MeshStandardMaterial({ color: "#c39776", roughness: 0.93 }), []);

  useLayoutEffect(() => {
    const bodyMesh = bodies.current;
    const headMesh = heads.current;
    if (!bodyMesh || !headMesh) return;
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    spots.forEach((spot, index) => {
      dummy.position.set(spot.x, spot.y + 0.48 * spot.scale, spot.z);
      dummy.rotation.set(0, spot.rotation, 0);
      dummy.scale.set(spot.scale, spot.scale, spot.scale);
      dummy.updateMatrix();
      bodyMesh.setMatrixAt(index, dummy.matrix);
      color.set(CROWD_COLORS[spot.shade]);
      bodyMesh.setColorAt(index, color);
      dummy.position.set(spot.x, spot.y + 0.95 * spot.scale, spot.z);
      dummy.scale.setScalar(spot.scale);
      dummy.updateMatrix();
      headMesh.setMatrixAt(index, dummy.matrix);
    });
    bodyMesh.instanceMatrix.needsUpdate = true;
    headMesh.instanceMatrix.needsUpdate = true;
    if (bodyMesh.instanceColor) bodyMesh.instanceColor.needsUpdate = true;
  }, [spots]);

  useFrame(({ clock }) => {
    const bodyMesh = bodies.current;
    const headMesh = heads.current;
    if (!bodyMesh || !headMesh) return;
    const time = clock.elapsedTime;
    animatedIndices.forEach((index) => {
      const spot = spots[index];
      const bob = Math.max(0, Math.sin(time * 2.7 + index * 0.41)) * 0.055;
      dummy.position.set(spot.x, spot.y + 0.48 * spot.scale + bob, spot.z);
      dummy.rotation.set(0, spot.rotation, Math.sin(time * 2.2 + index) * 0.018);
      dummy.scale.set(spot.scale, spot.scale, spot.scale);
      dummy.updateMatrix();
      bodyMesh.setMatrixAt(index, dummy.matrix);
      dummy.position.set(spot.x, spot.y + 0.95 * spot.scale + bob, spot.z);
      dummy.rotation.set(0, spot.rotation, 0);
      dummy.updateMatrix();
      headMesh.setMatrixAt(index, dummy.matrix);
    });
    bodyMesh.instanceMatrix.needsUpdate = true;
    headMesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <group>
      <instancedMesh ref={bodies} args={[bodyGeometry, bodyMaterial, spots.length]} frustumCulled={false} castShadow={false} />
      <instancedMesh ref={heads} args={[headGeometry, headMaterial, spots.length]} frustumCulled={false} castShadow={false} />
    </group>
  );
}

function Bleachers() {
  const rows = [];
  for (const side of [-1, 1]) {
    for (let row = 0; row < 14; row += 1) {
      rows.push(<mesh key={`lower-side-${side}-${row}`} position={[0, 2.7 + row * 0.52, side * (42.1 + row * 0.96)]} receiveShadow><boxGeometry args={[134, 0.24, 0.95]} /><meshStandardMaterial color={row % 3 === 0 ? "#455150" : "#343f40"} roughness={0.88} /></mesh>);
    }
    for (let row = 0; row < 12; row += 1) {
      rows.push(<mesh key={`upper-side-${side}-${row}`} position={[0, 11.9 + row * 0.68, side * (59.8 + row * 1.08)]} receiveShadow><boxGeometry args={[132, 0.25, 1.04]} /><meshStandardMaterial color={row % 3 === 0 ? "#485351" : "#354141"} roughness={0.9} /></mesh>);
    }
  }
  for (const side of [-1, 1]) {
    for (let row = 0; row < 13; row += 1) {
      rows.push(<mesh key={`lower-end-${side}-${row}`} position={[side * (55 + row * 0.95), 2.7 + row * 0.53, 0]} receiveShadow><boxGeometry args={[0.92, 0.24, 76]} /><meshStandardMaterial color={row % 3 === 0 ? "#46504f" : "#333f3e"} roughness={0.9} /></mesh>);
    }
    for (let row = 0; row < 11; row += 1) {
      rows.push(<mesh key={`upper-end-${side}-${row}`} position={[side * (69.7 + row * 1.05), 11.4 + row * 0.7, 0]} receiveShadow><boxGeometry args={[1.05, 0.25, 75]} /><meshStandardMaterial color={row % 3 === 0 ? "#485452" : "#34403f"} roughness={0.9} /></mesh>);
    }
  }
  return <group>{rows}</group>;
}

function StadiumStructure({ quality }: { quality: GraphicsQuality }) {
  const screen = useMemo(makeScoreTexture, []);
  const steel = "#3a4848";
  const roofBeam = useMemo(() => new THREE.MeshStandardMaterial({ color: steel, metalness: 0.72, roughness: 0.31 }), []);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.18, 0]} receiveShadow>
        <planeGeometry args={[300, 250]} />
        <meshStandardMaterial color="#111a1b" roughness={1} />
      </mesh>
      <mesh position={[0, -0.31, 0]} receiveShadow>
        <boxGeometry args={[141, 0.36, 95]} />
        <meshStandardMaterial color="#252f31" roughness={0.83} metalness={0.14} />
      </mesh>
      <Bleachers />
      <Crowd quality={quality} />
      <mesh position={[0, 24.5, -73]} castShadow receiveShadow><boxGeometry args={[163, 2.3, 21]} /><meshStandardMaterial color="#202a2c" metalness={0.48} roughness={0.49} /></mesh>
      <mesh position={[0, 24.5, 73]} castShadow receiveShadow><boxGeometry args={[163, 2.3, 21]} /><meshStandardMaterial color="#202a2c" metalness={0.48} roughness={0.49} /></mesh>
      <mesh position={[-80, 24.5, 0]} castShadow receiveShadow><boxGeometry args={[21, 2.3, 126]} /><meshStandardMaterial color="#202a2c" metalness={0.48} roughness={0.49} /></mesh>
      <mesh position={[80, 24.5, 0]} castShadow receiveShadow><boxGeometry args={[21, 2.3, 126]} /><meshStandardMaterial color="#202a2c" metalness={0.48} roughness={0.49} /></mesh>
      {Array.from({ length: 10 }, (_, index) => {
        const x = -70 + index * 15.5;
        return (
          <group key={`truss-${index}`}>
            <mesh position={[x, 23.6, -64]} castShadow material={roofBeam}><boxGeometry args={[0.42, 21, 0.42]} /></mesh>
            <mesh position={[x, 23.6, 64]} castShadow material={roofBeam}><boxGeometry args={[0.42, 21, 0.42]} /></mesh>
            <mesh position={[x, 34, 0]} rotation={[0, 0, Math.PI / 2]} material={roofBeam}><cylinderGeometry args={[0.18, 0.18, 127, 7]} /></mesh>
            <mesh position={[x, 31, -33]} rotation={[0, 0, Math.PI / 4]} material={roofBeam}><boxGeometry args={[0.28, 76, 0.28]} /></mesh>
            <mesh position={[x, 31, 33]} rotation={[0, 0, -Math.PI / 4]} material={roofBeam}><boxGeometry args={[0.28, 76, 0.28]} /></mesh>
          </group>
        );
      })}
      {[-1, 1].map((side) => (
        <group key={`roof-rib-${side}`}>
          {Array.from({ length: 8 }, (_, index) => (
            <mesh key={index} position={[side * 69, 23 + index * 0.15, -57 + index * 15.5]} rotation={[0, 0, side * 0.08]}>
              <boxGeometry args={[0.55, 20 + index * 0.15, 0.45]} />
              <meshStandardMaterial color="#394747" metalness={0.65} roughness={0.34} />
            </mesh>
          ))}
        </group>
      ))}
      {[-1, 1].map((side) => (
        <mesh key={`stadium-screen-${side}`} position={[side * 64.1, 22, 0]} rotation={[0, side === -1 ? Math.PI / 2 : -Math.PI / 2, 0]}>
          <planeGeometry args={[18, 7.5]} />
          <meshStandardMaterial map={screen} emissive="#536353" emissiveMap={screen} emissiveIntensity={0.42} roughness={0.58} side={THREE.DoubleSide} />
        </mesh>
      ))}
    </group>
  );
}

function Floodlight({ x, z, quality }: { x: number; z: number; quality: GraphicsQuality }) {
  const panelRef = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => new THREE.SphereGeometry(0.21, 8, 6), []);
  const material = useMemo(() => new THREE.MeshBasicMaterial({ color: "#e7ffe7" }), []);
  const isNearSide = z > 0;
  useLayoutEffect(() => {
    if (!panelRef.current) return;
    const object = new THREE.Object3D();
    for (let index = 0; index < 18; index += 1) {
      object.position.set(x + (index % 6) * (x > 0 ? -1.05 : 1.05), 35.2, z + Math.floor(index / 6) * (isNearSide ? -0.8 : 0.8));
      object.updateMatrix();
      panelRef.current.setMatrixAt(index, object.matrix);
    }
    panelRef.current.instanceMatrix.needsUpdate = true;
  }, [x, z, isNearSide]);
  return (
    <group>
      <mesh position={[x, 18, z]} castShadow><boxGeometry args={[0.65, 36, 0.65]} /><meshStandardMaterial color="#455153" metalness={0.72} roughness={0.32} /></mesh>
      <mesh position={[x, 35.3, z]}><boxGeometry args={[7, 0.72, 2.3]} /><meshStandardMaterial color="#303b3d" metalness={0.68} roughness={0.3} /></mesh>
      <instancedMesh ref={panelRef} args={[geometry, material, 18]} />
      {quality === "HIGH" && <spotLight position={[x, 34.5, z]} intensity={620} angle={0.8} penumbra={0.7} distance={125} decay={1.65} color="#e9f7df" castShadow={false} />}
    </group>
  );
}

function GrassWeather({ weather, quality }: { weather: Weather; quality: GraphicsQuality }) {
  const points = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const dropCount = quality === "PERFORMANCE" ? 320 : quality === "BALANCED" ? 750 : 1300;
    const values = new Float32Array(dropCount * 3);
    let seed = 2187;
    const random = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let index = 0; index < values.length; index += 3) {
      values[index] = (random() - 0.5) * 132;
      values[index + 1] = random() * 27 + 2;
      values[index + 2] = (random() - 0.5) * 94;
    }
    return values;
  }, [quality]);

  useFrame((_, delta) => {
    if (weather !== "RAIN" || !points.current) return;
    const attribute = points.current.geometry.getAttribute("position") as THREE.BufferAttribute;
    const values = attribute.array as Float32Array;
    for (let index = 0; index < values.length; index += 3) {
      values[index] += delta * 1.1;
      values[index + 1] -= delta * 19;
      if (values[index + 1] < 0.4) {
        values[index + 1] = 28 + (index % 13) * 0.3;
        values[index] = (values[index] % 132) - 66;
      }
    }
    attribute.needsUpdate = true;
  });

  if (weather !== "RAIN") return null;
  return (
    <points ref={points} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#c6e8ea" size={0.15} transparent opacity={0.56} sizeAttenuation depthWrite={false} />
    </points>
  );
}

export const Stadium = memo(function Stadium({ weather, timeOfDay, quality }: { weather: Weather; timeOfDay: TimeOfDay; quality: GraphicsQuality }) {
  const isDay = timeOfDay === "DAY";
  const isDusk = timeOfDay === "DUSK";
  const screenGlow = isDay ? "#fff4c7" : isDusk ? "#ffd2a2" : "#b8d9e6";
  const shadowSize = quality === "HIGH" ? 2048 : quality === "BALANCED" ? 1536 : 1024;

  return (
    <>
      {/* No distance fog: the full pitch, goalmouths and far stand stay legible. */}
      <color attach="background" args={[isDay ? "#8aa6ab" : isDusk ? "#4a3b43" : "#0c1b20"]} />
      <ambientLight intensity={isDay ? 1.65 : isDusk ? 1.24 : 1.1} color={isDay ? "#eef6e2" : "#cddde4"} />
      <hemisphereLight intensity={isDay ? 1.1 : 1.02} color={isDay ? "#dcecf4" : "#adc6d3"} groundColor="#22322b" />
      <directionalLight
        position={isDay ? [-38, 64, 28] : [-26, 58, 34]}
        intensity={isDay ? 2.35 : isDusk ? 1.9 : 1.78}
        color={isDay ? "#fff2d7" : isDusk ? "#ffd3ad" : "#e1eeff"}
        castShadow={quality !== "PERFORMANCE"}
        shadow-mapSize-width={shadowSize}
        shadow-mapSize-height={shadowSize}
        shadow-camera-left={-80}
        shadow-camera-right={80}
        shadow-camera-top={62}
        shadow-camera-bottom={-62}
        shadow-camera-near={1}
        shadow-camera-far={210}
        shadow-bias={-0.0003}
        shadow-normalBias={0.023}
      />
      <StadiumStructure quality={quality} />
      <Pitch weather={weather} quality={quality} />
      <AdBoards />
      <Goal side={-1} />
      <Goal side={1} />
      {[-1, 1].flatMap((side) => [-1, 1].map((depth) => <Floodlight key={`flood-${side}-${depth}`} x={side * 72} z={depth * 48} quality={quality} />))}
      <pointLight position={[0, 22, 0]} intensity={isDay ? 22 : 72} distance={150} decay={1.9} color={screenGlow} />
      <pointLight position={[-40, 15, 2]} intensity={isDay ? 12 : 52} distance={110} decay={2} color="#d7efff" />
      <pointLight position={[39, 17, -6]} intensity={isDay ? 12 : 52} distance={110} decay={2} color="#ffe1ba" />
      <GrassWeather weather={weather} quality={quality} />
    </>
  );
});