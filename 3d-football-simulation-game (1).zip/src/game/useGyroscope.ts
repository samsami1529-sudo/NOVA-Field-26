import { useCallback, useEffect, useRef, useState } from "react";

type SensorPermission = "idle" | "requesting" | "granted" | "denied" | "unsupported";

type DeviceOrientationEventWithPermission = typeof DeviceOrientationEvent & {
  requestPermission?: () => Promise<"granted" | "denied">;
};

type NativeSensorBridge = {
  isSupported: () => boolean;
  start: () => void;
  stop: () => void;
  getAzimuth: () => number;
  getPitch: () => number;
};

declare global {
  interface Window {
    AndroidSensors?: NativeSensorBridge;
  }
}

export type GyroscopeControls = {
  enabled: boolean;
  supported: boolean;
  permission: SensorPermission;
  error: string;
  yawRef: React.MutableRefObject<number>;
  pitchRef: React.MutableRefObject<number>;
  enable: () => Promise<void>;
  disable: () => void;
  calibrate: () => void;
};

const DEGREE = Math.PI / 180;
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

function screenAngle() {
  if (typeof window === "undefined") return 0;
  const orientation = window.screen?.orientation;
  if (orientation && typeof orientation.angle === "number") return orientation.angle;
  return typeof window.orientation === "number" ? window.orientation : 0;
}

/**
 * Reads device rotation and exposes a safe, clamped orbit target for the camera.
 * Only the camera orbits: the pitch, ball and simulation axes never rotate.
 */
export function useGyroscope(sensitivity: number): GyroscopeControls {
  const [enabled, setEnabled] = useState(false);
  const [permission, setPermission] = useState<SensorPermission>("idle");
  const [error, setError] = useState("");
  const nativeBridge = typeof window !== "undefined" ? window.AndroidSensors : undefined;
  const nativeSupported = (() => {
    try {
      return Boolean(nativeBridge?.isSupported?.());
    } catch {
      return false;
    }
  })();
  const supported = nativeSupported || (typeof window !== "undefined" && "DeviceOrientationEvent" in window);
  const yawRef = useRef(0);
  const pitchRef = useRef(0);
  const sensitivityRef = useRef(sensitivity);
  const baseline = useRef<{ alpha: number; beta: number } | null>(null);
  const latest = useRef<{ alpha: number; beta: number } | null>(null);
  sensitivityRef.current = sensitivity;

  const applyReading = useCallback((alpha: number, beta: number) => {
    latest.current = { alpha, beta };
    if (!baseline.current) baseline.current = { alpha, beta };
    const sideways = Math.abs(screenAngle()) === 90;
    const referencePitch = baseline.current.beta;
    const rawYaw = ((alpha - baseline.current.alpha + 540) % 360) - 180;
    // Camera orbit only. Clamping prevents a quick twist from swinging through
    // the stadium, while world coordinates and gameplay axes stay untouched.
    const yawDegrees = clamp(sideways ? rawYaw : rawYaw * 0.8, -52, 52);
    const pitchDegrees = clamp((beta - referencePitch) * (sideways ? 0.32 : 0.22), -12, 18);
    yawRef.current = yawDegrees * DEGREE * sensitivityRef.current;
    pitchRef.current = pitchDegrees * DEGREE * sensitivityRef.current;
  }, []);

  const calibrate = useCallback(() => {
    baseline.current = latest.current ? { ...latest.current } : null;
    yawRef.current = 0;
    pitchRef.current = 0;
  }, []);

  const disable = useCallback(() => {
    setEnabled(false);
    setPermission("idle");
    setError("");
    yawRef.current = 0;
    pitchRef.current = 0;
    baseline.current = null;
  }, []);

  const enable = useCallback(async () => {
    setError("");
    if (!supported) {
      setPermission("unsupported");
      setError("Motion sensors are not exposed by this browser or WebView.");
      return;
    }
    setPermission("requesting");
    if (nativeSupported) {
      baseline.current = null;
      setPermission("granted");
      setEnabled(true);
      return;
    }
    try {
      const orientationConstructor = window.DeviceOrientationEvent as DeviceOrientationEventWithPermission;
      if (typeof orientationConstructor.requestPermission === "function") {
        const response = await orientationConstructor.requestPermission();
        if (response !== "granted") {
          setPermission("denied");
          setError("Motion access was declined. Allow it in browser settings, then try again.");
          return;
        }
      }
      baseline.current = null;
      setPermission("granted");
      setEnabled(true);
    } catch {
      setPermission("denied");
      setError("Motion access could not be enabled. A secure page or installed app is required.");
    }
  }, [nativeSupported, supported]);

  // Native sensor fallback used by the signed Android build. It polls at 30 Hz,
  // avoiding WebView sensor inconsistencies while retaining the same clamped orbit.
  useEffect(() => {
    if (!enabled || !nativeBridge || !nativeSupported) return;
    try {
      nativeBridge.start();
    } catch {
      setError("The Android gyroscope could not be started.");
      return;
    }
    const timer = window.setInterval(() => {
      try {
        const alpha = nativeBridge.getAzimuth();
        const beta = nativeBridge.getPitch();
        if (Number.isFinite(alpha) && Number.isFinite(beta)) applyReading(alpha, beta);
      } catch {
        // A sensor can disappear when another app takes ownership.
      }
    }, 33);
    return () => {
      window.clearInterval(timer);
      try {
        nativeBridge.stop();
      } catch {
        // Ignore shutdown races.
      }
    };
  }, [applyReading, enabled, nativeBridge, nativeSupported]);

  useEffect(() => {
    if (!enabled || nativeSupported) return;
    let receivedReading = false;
    const handleOrientation = (event: DeviceOrientationEvent) => {
      if (typeof event.alpha !== "number") return;
      receivedReading = true;
      applyReading(event.alpha, typeof event.beta === "number" ? event.beta : 0);
    };
    const handleDisabled = () => {
      setError("Motion sensors became unavailable.");
      setEnabled(false);
      setPermission("denied");
    };
    window.addEventListener("deviceorientation", handleOrientation, true);
    const timer = window.setTimeout(() => {
      if (!receivedReading) {
        setError("No motion data received. Check sensor permission and move your phone gently.");
      }
    }, 2400);
    window.addEventListener("deviceorientationerror", handleDisabled);
    return () => {
      window.removeEventListener("deviceorientation", handleOrientation, true);
      window.removeEventListener("deviceorientationerror", handleDisabled);
      window.clearTimeout(timer);
    };
  }, [applyReading, enabled, nativeSupported]);

  return {
    enabled,
    supported,
    permission,
    error,
    yawRef,
    pitchRef,
    enable,
    disable,
    calibrate,
  };
}
