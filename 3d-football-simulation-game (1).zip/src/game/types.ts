export type GameMode = "KICK OFF" | "CAREER" | "TOURNAMENT" | "TRAINING" | "PENALTIES";
export type Weather = "CLEAR" | "RAIN";
export type TimeOfDay = "NIGHT" | "DUSK" | "DAY";
export type Formation = "4-3-3" | "4-2-3-1" | "3-5-2";
export type GraphicsQuality = "PERFORMANCE" | "BALANCED" | "HIGH";
export type CameraStyle = "BROADCAST" | "TACTICAL";

export type TeamDefinition = {
  id: string;
  name: string;
  short: string;
  city: string;
  colors: {
    kit: string;
    trim: string;
    shorts: string;
    socks: string;
    keeper: string;
    keeperTrim: string;
  };
};

export type Player = {
  id: string;
  team: 0 | 1;
  number: number;
  name: string;
  role: string;
  x: number;
  z: number;
  baseX: number;
  baseZ: number;
  vx: number;
  vz: number;
  angle: number;
  stamina: number;
  height: number;
  build: number;
  skin: string;
  hair: string;
  hairStyle: number;
  keeper: boolean;
  visible: boolean;
  actionUntil: number;
};

export type Ball = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  ownerId: string | null;
  passTargetId: string | null;
  kickAge: number;
};

export type MatchState = {
  players: Player[];
  ball: Ball;
  score: [number, number];
  elapsed: number;
  selectedId: string;
  mode: GameMode;
  formation: Formation;
  possessionTime: number;
  aiCooldown: number;
  goalPause: number;
  pendingKickoffTeam: 0 | 1;
  event: string;
  eventTime: number;
  finished: boolean;
  randomSeed: number;
  difficulty: "CASUAL" | "COMPETITIVE" | "WORLD CLASS";
  penaltyTeam: 0 | 1;
  penaltyAttempts: [number, number];
  penaltyShotTeam: 0 | 1 | null;
  penaltyPause: number;
  penaltyAimZ: number;
  penaltyAimHeight: number;
  penaltyKeeperTarget: number;
  penaltyResults: Array<boolean | null>;
};

export type InputState = {
  down: Set<string>;
  pressed: Set<string>;
};

export type MatchSnapshot = {
  score: [number, number];
  elapsed: number;
  selectedId: string;
  playerName: string;
  playerRole: string;
  stamina: number;
  event: string;
  mode: GameMode;
  possession: 0 | 1 | null;
  penaltyTeam: 0 | 1;
  penaltyAttempts: [number, number];
  penaltyAimZ: number;
  finished: boolean;
};