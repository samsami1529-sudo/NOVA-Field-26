import type { Formation, GameMode, InputState, MatchSnapshot, MatchState, Player, TeamDefinition } from "./types";

const FIELD_X = 52;
const FIELD_Z = 34;
const GOAL_X = 52.15;
const GOAL_HALF_WIDTH = 3.66;
const SKIN_TONES = ["#b77959", "#e1ae88", "#9a6048", "#f0c8a4", "#704637", "#c78d6b"];
const HAIR_TONES = ["#201b19", "#523b2d", "#a27348", "#312d35", "#6d4e3b"];

const LINEUPS: Record<Formation, Array<[string, number, number]>> = {
  "4-3-3": [
    ["GK", -49, 0],
    ["LB", -32, -24],
    ["CB", -36, -8],
    ["CB", -36, 8],
    ["RB", -32, 24],
    ["CM", -13, -14],
    ["CM", -17, 0],
    ["CM", -13, 14],
    ["LW", 11, -19],
    ["ST", 0, 0],
    ["RW", 11, 19],
  ],
  "4-2-3-1": [
    ["GK", -49, 0],
    ["LB", -32, -24],
    ["CB", -36, -8],
    ["CB", -36, 8],
    ["RB", -32, 24],
    ["CDM", -19, -10],
    ["CDM", -21, 10],
    ["LW", -3, -19],
    ["CAM", 1, 0],
    ["RW", -3, 19],
    ["ST", 15, 0],
  ],
  "3-5-2": [
    ["GK", -49, 0],
    ["CB", -36, -17],
    ["CB", -39, 0],
    ["CB", -36, 17],
    ["RM", -15, 25],
    ["CM", -20, -11],
    ["CM", -21, 0],
    ["CM", -20, 11],
    ["LM", -15, -25],
    ["ST", 8, -8],
    ["ST", 8, 8],
  ],
};

const NAMES = [
  "M. Wells", "D. Okafor", "L. Petrov", "J. Navarro", "A. Mensah", "S. Ito",
  "T. Cole", "R. Silva", "A. Clarke", "J. Williams", "N. Diallo",
];

function nextRandom(state: MatchState) {
  state.randomSeed = (state.randomSeed * 1664525 + 1013904223) >>> 0;
  return state.randomSeed / 4294967296;
}

function makePlayer(team: 0 | 1, index: number, formation: Formation): Player {
  const [role, baseX, baseZ] = LINEUPS[formation][index];
  const x = team === 0 ? baseX : -baseX;
  const number = [1, 3, 4, 5, 2, 8, 6, 10, 7, 9, 11][index];
  return {
    id: `${team}-${index}`,
    team,
    number,
    name: NAMES[(index + team * 4) % NAMES.length],
    role,
    x,
    z: baseZ,
    baseX: x,
    baseZ,
    vx: 0,
    vz: 0,
    angle: team === 0 ? Math.PI / 2 : -Math.PI / 2,
    stamina: 100,
    height: 0.94 + ((index * 7 + team * 3) % 7) * 0.018,
    build: 0.92 + ((index * 3 + team) % 5) * 0.035,
    skin: SKIN_TONES[(index + team * 3) % SKIN_TONES.length],
    hair: HAIR_TONES[(index * 2 + team) % HAIR_TONES.length],
    hairStyle: (index + team) % 4,
    keeper: index === 0,
    visible: true,
    actionUntil: 0,
  };
}

function setKickoff(state: MatchState, team: 0 | 1) {
  state.players.forEach((player) => {
    player.visible = true;
    player.x = player.baseX;
    player.z = player.baseZ;
    player.vx = 0;
    player.vz = 0;
    player.actionUntil = 0;
  });
  const kicker = state.players.find((player) => player.id === `${team}-9`)!;
  const otherKicker = state.players.find((player) => player.id === `${1 - team}-9`)!;
  kicker.x = team === 0 ? -0.95 : 0.95;
  kicker.z = 0;
  kicker.angle = team === 0 ? Math.PI / 2 : -Math.PI / 2;
  otherKicker.x = team === 0 ? 1.55 : -1.55;
  otherKicker.z = 0;
  state.ball = {
    x: kicker.x + (team === 0 ? 0.62 : -0.62),
    y: 0.23,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    ownerId: kicker.id,
    passTargetId: null,
    kickAge: 0,
  };
  state.pendingKickoffTeam = team;
  state.possessionTime = 0;
  state.selectedId = team === 0 ? "0-9" : "0-9";
}

function setupPenalty(state: MatchState, team: 0 | 1) {
  const direction = team === 0 ? 1 : -1;
  state.penaltyTeam = team;
  state.penaltyShotTeam = null;
  state.penaltyAimZ = 0;
  state.penaltyAimHeight = 0.32;
  state.penaltyResults = [...state.penaltyResults, null];
  state.players.forEach((player) => {
    player.visible = false;
    player.vx = 0;
    player.vz = 0;
  });
  const shooter = state.players.find((player) => player.id === `${team}-9`)!;
  const goalkeeper = state.players.find((player) => player.id === `${1 - team}-0`)!;
  shooter.visible = true;
  shooter.x = direction * 38.2;
  shooter.z = 0;
  shooter.baseX = shooter.x;
  shooter.baseZ = 0;
  shooter.angle = direction * Math.PI / 2;
  goalkeeper.visible = true;
  goalkeeper.x = direction * 49.15;
  goalkeeper.z = 0;
  goalkeeper.baseX = goalkeeper.x;
  goalkeeper.baseZ = 0;
  goalkeeper.angle = -direction * Math.PI / 2;
  state.selectedId = shooter.id;
  state.ball = {
    x: direction * 40.15,
    y: 0.23,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    ownerId: shooter.id,
    passTargetId: null,
    kickAge: 0,
  };
}

export function createMatch(mode: GameMode, home: TeamDefinition, away: TeamDefinition): MatchState {
  const state: MatchState = {
    players: [...Array.from({ length: 11 }, (_, index) => makePlayer(0, index, "4-3-3")), ...Array.from({ length: 11 }, (_, index) => makePlayer(1, index, "4-3-3"))],
    ball: { x: 0, y: 0.23, z: 0, vx: 0, vy: 0, vz: 0, ownerId: null, passTargetId: null, kickAge: 0 },
    score: [0, 0],
    elapsed: 0,
    selectedId: "0-9",
    mode,
    formation: "4-3-3",
    possessionTime: 0,
    aiCooldown: 1.6,
    goalPause: 0,
    pendingKickoffTeam: 0,
    event: "",
    eventTime: 0,
    finished: false,
    randomSeed: 9137 + home.id.length * 31 + away.id.length * 13,
    difficulty: "COMPETITIVE",
    penaltyTeam: 0,
    penaltyAttempts: [0, 0],
    penaltyShotTeam: null,
    penaltyPause: 0,
    penaltyAimZ: 0,
    penaltyAimHeight: 0.32,
    penaltyKeeperTarget: 0,
    penaltyResults: [],
  };
  if (mode === "PENALTIES") setupPenalty(state, 0);
  else setKickoff(state, 0);
  return state;
}

function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value));
}

function playerById(state: MatchState, id: string | null) {
  return id ? state.players.find((player) => player.id === id) ?? null : null;
}

function moveToward(player: Player, targetX: number, targetZ: number, speed: number, dt: number) {
  const dx = targetX - player.x;
  const dz = targetZ - player.z;
  const distance = Math.hypot(dx, dz);
  const acceleration = Math.min(1, dt * 6.8);
  const pace = distance < 0.18 ? 0 : Math.min(speed, distance * 2.7);
  const targetVx = distance > 0.001 ? (dx / distance) * pace : 0;
  const targetVz = distance > 0.001 ? (dz / distance) * pace : 0;
  player.vx += (targetVx - player.vx) * acceleration;
  player.vz += (targetVz - player.vz) * acceleration;
  player.x = clamp(player.x + player.vx * dt, -FIELD_X - 1.8, FIELD_X + 1.8);
  player.z = clamp(player.z + player.vz * dt, -FIELD_Z + 0.5, FIELD_Z - 0.5);
  if (Math.hypot(player.vx, player.vz) > 0.24) player.angle = Math.atan2(player.vx, player.vz);
}

function nearestByTeam(state: MatchState, team: 0 | 1, count: number) {
  return state.players
    .filter((player) => player.team === team && !player.keeper)
    .sort((a, b) => Math.hypot(a.x - state.ball.x, a.z - state.ball.z) - Math.hypot(b.x - state.ball.x, b.z - state.ball.z))
    .slice(0, count);
}

function setEvent(state: MatchState, label: string, duration = 1.8) {
  state.event = label;
  state.eventTime = duration;
}

function launchBall(state: MatchState, player: Player, dx: number, dz: number, power: number, lift: number, targetId: string | null = null) {
  const length = Math.hypot(dx, dz) || 1;
  state.ball.ownerId = null;
  state.ball.passTargetId = targetId;
  state.ball.x = player.x + (dx / length) * 0.7;
  state.ball.y = 0.24;
  state.ball.z = player.z + (dz / length) * 0.7;
  state.ball.vx = (dx / length) * power;
  state.ball.vz = (dz / length) * power;
  state.ball.vy = lift;
  state.ball.kickAge = 0;
  player.actionUntil = 0.38;
  state.possessionTime = 0;
}

function passBall(state: MatchState, player: Player, through = false) {
  const direction = player.team === 0 ? 1 : -1;
  const candidates = state.players.filter((candidate) => candidate.team === player.team && candidate.id !== player.id && !candidate.keeper);
  const receiver = candidates
    .map((candidate) => {
      const forward = (candidate.x - player.x) * direction;
      const distance = Math.hypot(candidate.x - player.x, candidate.z - player.z);
      const space = Math.hypot(candidate.x - state.ball.x, candidate.z - state.ball.z);
      return { candidate, score: forward * (through ? 1.35 : 0.78) - Math.abs(candidate.z - player.z) * 0.18 - distance * 0.16 + space * 0.06 };
    })
    .sort((a, b) => b.score - a.score)[0]?.candidate;
  if (!receiver) return;
  const opponents = state.players
    .filter((candidate) => candidate.team !== player.team && !candidate.keeper)
    .map((candidate) => candidate.x * direction)
    .sort((a, b) => b - a);
  const secondLastDefender = opponents[1] ?? -FIELD_X;
  const receiverProgress = receiver.x * direction;
  const ballProgress = player.x * direction;
  if (receiverProgress > 0 && receiverProgress > secondLastDefender + 0.35 && receiverProgress > ballProgress + 0.35) {
    const defender = state.players
      .filter((candidate) => candidate.team !== player.team && !candidate.keeper)
      .sort((a, b) => Math.hypot(a.x - receiver.x, a.z - receiver.z) - Math.hypot(b.x - receiver.x, b.z - receiver.z))[0];
    state.ball.ownerId = defender?.id ?? null;
    state.ball.passTargetId = null;
    state.ball.x = receiver.x;
    state.ball.y = 0.23;
    state.ball.z = receiver.z;
    state.ball.vx = 0;
    state.ball.vy = 0;
    state.ball.vz = 0;
    state.possessionTime = 0;
    setEvent(state, "OFFSIDE", 1.35);
    return;
  }
  const lead = through ? Math.min(4, Math.hypot(receiver.vx, receiver.vz) * 0.42 + 1.6) : 0.25;
  const dx = receiver.x + direction * lead - player.x;
  const dz = receiver.z + receiver.vz * (through ? 0.35 : 0.14) - player.z;
  launchBall(state, player, dx, dz, through ? 23 : 18.5, through ? 1.4 : 0.55, receiver.id);
  setEvent(state, through ? "THROUGH BALL" : "PASS", 1.05);
}

function shootBall(state: MatchState, player: Player) {
  const direction = player.team === 0 ? 1 : -1;
  const targetX = direction * (GOAL_X + 0.3);
  const targetZ = clamp(-player.z * 0.18 + (nextRandom(state) - 0.5) * 2.2, -3.05, 3.05);
  launchBall(state, player, targetX - player.x, targetZ - player.z, 24.5 + nextRandom(state) * 4, 2.0 + nextRandom(state) * 0.7);
  state.ball.kickAge = 0;
  state.ball.passTargetId = null;
  setEvent(state, "SHOT", 0.9);
}

function registerGoal(state: MatchState, team: 0 | 1) {
  state.score[team] += 1;
  state.ball.ownerId = null;
  state.ball.passTargetId = null;
  state.ball.vx = 0;
  state.ball.vy = 0;
  state.ball.vz = 0;
  state.ball.y = 0.23;
  state.goalPause = 2.35;
  state.pendingKickoffTeam = team === 0 ? 1 : 0;
  setEvent(state, "GOAL", 2.4);
}

function attemptPenalty(state: MatchState, player: Player) {
  const team = state.penaltyTeam;
  const direction = team === 0 ? 1 : -1;
  const keeper = playerById(state, `${1 - team}-0`);
  state.penaltyShotTeam = team;
  const targetZ = clamp(state.penaltyAimZ, -3.05, 3.05);
  state.penaltyKeeperTarget = clamp(targetZ * 0.42 + (nextRandom(state) - 0.5) * 2.8, -3.3, 3.3);
  if (keeper) keeper.actionUntil = 1.0;
  launchBall(state, player, direction * (GOAL_X - 40.4), targetZ, 25.5, state.penaltyAimHeight * 2.4);
  state.ball.x = direction * 40.15;
  state.ball.z = 0;
  state.ball.kickAge = 0;
  state.ball.passTargetId = null;
  setEvent(state, "PENALTY", 0.85);
}

function finishPenalty(state: MatchState, scored: boolean, saved = false) {
  const team = state.penaltyShotTeam;
  if (team === null) return;
  state.penaltyAttempts[team] += 1;
  state.penaltyResults.push(scored);
  if (scored) state.score[team] += 1;
  state.penaltyShotTeam = null;
  state.ball.ownerId = null;
  state.ball.passTargetId = null;
  state.ball.vx = 0;
  state.ball.vy = 0;
  state.ball.vz = 0;
  const decidedAfterFive = state.penaltyAttempts[0] >= 5 && state.penaltyAttempts[1] >= 5 && state.score[0] !== state.score[1];
  state.finished = decidedAfterFive;
  state.penaltyPause = decidedAfterFive ? 0 : 1.7;
  setEvent(state, decidedAfterFive ? "SHOOTOUT WON" : scored ? "GOAL" : saved ? "SAVED" : "WIDE", decidedAfterFive ? 5 : 1.7);
}

function updatePenalty(state: MatchState, input: InputState, dt: number) {
  if (state.eventTime > 0) state.eventTime = Math.max(0, state.eventTime - dt);
  if (state.finished) {
    input.pressed.clear();
    return;
  }
  const shooter = playerById(state, state.selectedId);
  const goalkeeper = playerById(state, `${1 - state.penaltyTeam}-0`);

  if (state.penaltyPause > 0) {
    state.penaltyPause -= dt;
    if (state.penaltyPause <= 0) setupPenalty(state, state.penaltyTeam === 0 ? 1 : 0);
    input.pressed.clear();
    return;
  }

  if (state.penaltyShotTeam !== null) {
    const keeper = playerById(state, `${1 - state.penaltyShotTeam}-0`);
    if (keeper) {
      const delta = state.penaltyKeeperTarget - keeper.z;
      keeper.z += clamp(delta, -dt * 9.5, dt * 9.5);
    }
    state.ball.kickAge += dt;
    state.ball.x += state.ball.vx * dt;
    state.ball.y += state.ball.vy * dt;
    state.ball.z += state.ball.vz * dt;
    state.ball.vy -= 9.8 * dt;
    if (state.ball.y < 0.23) {
      state.ball.y = 0.23;
      state.ball.vy = Math.max(0, -state.ball.vy * 0.28);
      state.ball.vx *= 0.98;
      state.ball.vz *= 0.98;
    }
    if (keeper && Math.abs(state.ball.x - keeper.x) < 0.85 && Math.abs(state.ball.z - keeper.z) < 1.05 && state.ball.y < 2.2) {
      finishPenalty(state, false, true);
    } else if (Math.abs(state.ball.x) >= GOAL_X) {
      const scored = Math.abs(state.ball.z) <= GOAL_HALF_WIDTH && state.ball.y < 2.45;
      finishPenalty(state, scored);
    } else if (Math.abs(state.ball.z) > FIELD_Z + 2 || state.ball.kickAge > 2.2) {
      finishPenalty(state, false);
    }
    input.pressed.clear();
    return;
  }

  if (!shooter || !goalkeeper) return;
  const leftAim = input.pressed.has("KeyA") || input.pressed.has("ArrowLeft");
  const rightAim = input.pressed.has("KeyD") || input.pressed.has("ArrowRight");
  const higherAim = input.pressed.has("KeyW") || input.pressed.has("ArrowUp");
  const lowerAim = input.pressed.has("KeyS") || input.pressed.has("ArrowDown");
  if (leftAim) state.penaltyAimZ = clamp(state.penaltyAimZ - 0.75, -3.05, 3.05);
  if (rightAim) state.penaltyAimZ = clamp(state.penaltyAimZ + 0.75, -3.05, 3.05);
  if (higherAim) state.penaltyAimHeight = clamp(state.penaltyAimHeight + 0.11, 0.24, 1.25);
  if (lowerAim) state.penaltyAimHeight = clamp(state.penaltyAimHeight - 0.11, 0.24, 1.25);
  goalkeeper.z += clamp(-goalkeeper.z, -dt * 4, dt * 4);
  if (input.pressed.has("KeyK") || input.pressed.has("Enter")) attemptPenalty(state, shooter);
  input.pressed.clear();
}

function updateMatch(state: MatchState, input: InputState, dt: number) {
  if (state.eventTime > 0) state.eventTime = Math.max(0, state.eventTime - dt);
  if (state.goalPause > 0) {
    state.goalPause -= dt;
    if (state.goalPause <= 0) setKickoff(state, state.pendingKickoffTeam);
    input.pressed.clear();
    return;
  }
  if (state.finished) {
    input.pressed.clear();
    return;
  }

  state.elapsed += dt;
  if (state.elapsed * 45 >= 90 * 60) {
    state.finished = true;
    setEvent(state, "FULL TIME", 5);
    input.pressed.clear();
    return;
  }

  if (input.pressed.has("Tab")) {
    const homePlayers = state.players.filter((player) => player.team === 0 && !player.keeper);
    const currentIndex = homePlayers.findIndex((player) => player.id === state.selectedId);
    const next = homePlayers[(currentIndex + 1 + homePlayers.length) % homePlayers.length];
    if (next) state.selectedId = next.id;
  }

  const selected = playerById(state, state.selectedId);
  const owner = playerById(state, state.ball.ownerId);
  const ball = state.ball;
  const pressed = input.pressed;
  const userHasBall = selected !== null && owner?.id === selected.id;

  if (selected && !selected.keeper) {
    if (pressed.has("KeyJ") && userHasBall) passBall(state, selected, false);
    else if (pressed.has("KeyL") && userHasBall) passBall(state, selected, true);
    else if (pressed.has("KeyK") && userHasBall) shootBall(state, selected);

    if (pressed.has("KeyQ") && selected && owner && owner.team !== selected.team && Math.hypot(selected.x - owner.x, selected.z - owner.z) < 2.2) {
      const attackDirection = owner.team === 0 ? 1 : -1;
      const isFromBehind = (selected.x - owner.x) * attackDirection < -0.3;
      if (isFromBehind && nextRandom(state) < 0.27) {
        ball.ownerId = owner.id;
        ball.passTargetId = null;
        ball.x = owner.x + Math.sin(owner.angle) * 0.68;
        ball.y = 0.23;
        ball.z = owner.z + Math.cos(owner.angle) * 0.68;
        ball.vx = owner.vx;
        ball.vy = 0;
        ball.vz = owner.vz;
        state.possessionTime = 0;
        owner.actionUntil = 0.24;
        setEvent(state, "FOUL / FREE KICK", 1.45);
      } else {
        ball.ownerId = null;
        ball.passTargetId = null;
        ball.x = owner.x;
        ball.y = 0.23;
        ball.z = owner.z;
        ball.vx = -owner.vx * 0.45 + (selected.team === 0 ? 2.2 : -2.2);
        ball.vy = 0.35;
        ball.vz = (nextRandom(state) - 0.5) * 4;
        owner.actionUntil = 0.28;
        setEvent(state, "CLEAN TACKLE", 1.2);
      }
    }
  }

  const latestOwner = playerById(state, ball.ownerId);
  state.aiCooldown -= dt;

  const homeChasers = nearestByTeam(state, 0, 2);
  const awayChasers = nearestByTeam(state, 1, 2);
  const movementX = Number(input.down.has("KeyW") || input.down.has("ArrowUp")) - Number(input.down.has("KeyS") || input.down.has("ArrowDown"));
  const movementZ = Number(input.down.has("KeyD") || input.down.has("ArrowRight")) - Number(input.down.has("KeyA") || input.down.has("ArrowLeft"));
  const movementLength = Math.hypot(movementX, movementZ) || 1;
  const sprinting = input.down.has("ShiftLeft") || input.down.has("ShiftRight");

  state.players.forEach((player) => {
    if (state.mode === "PENALTIES" && !player.visible) return;
    if (state.mode === "PENALTIES" && player.keeper) return;
    if (player.keeper) {
      const direction = player.team === 0 ? -1 : 1;
      moveToward(player, direction * 48.7, clamp(ball.z * 0.46, -3.1, 3.1), 4.4, dt);
      return;
    }

    if (player.id === state.selectedId && player.team === 0) {
      if (movementX || movementZ) {
        const speed = sprinting && player.stamina > 4 ? 9.4 : 6.7;
        const targetVx = (movementX / movementLength) * speed;
        const targetVz = (movementZ / movementLength) * speed;
        player.vx += (targetVx - player.vx) * Math.min(1, dt * 9);
        player.vz += (targetVz - player.vz) * Math.min(1, dt * 9);
        player.x = clamp(player.x + player.vx * dt, -FIELD_X + 0.5, FIELD_X - 0.5);
        player.z = clamp(player.z + player.vz * dt, -FIELD_Z + 0.5, FIELD_Z - 0.5);
        player.angle = Math.atan2(player.vx, player.vz);
        player.stamina = Math.max(12, player.stamina - (sprinting ? dt * 3.8 : dt * 0.2));
      } else {
        player.vx *= Math.max(0, 1 - dt * 8);
        player.vz *= Math.max(0, 1 - dt * 8);
        player.stamina = Math.min(100, player.stamina + dt * 0.7);
      }
      return;
    }

    const teamDirection = player.team === 0 ? 1 : -1;
    const ownBall = latestOwner?.team === player.team;
    let targetX = player.baseX;
    let targetZ = player.baseZ;
    let pace = 5.0;
    if (latestOwner?.id === player.id) {
      const distanceToGoal = Math.abs(teamDirection * FIELD_X - player.x);
      targetX = player.x + teamDirection * (distanceToGoal < 25 ? 1.0 : 3.0);
      targetZ = player.z * 0.72;
      pace = 5.4;
    } else if (ownBall) {
      const progress = clamp((latestOwner!.x * teamDirection + 12) / 60, 0, 1);
      targetX = player.baseX + teamDirection * (progress * (player.role.includes("ST") || player.role.includes("W") ? 8 : 3));
      targetZ = player.baseZ + clamp((latestOwner!.z - player.baseZ) * 0.18, -6, 6);
      pace = 4.8;
    } else {
      const chasers = player.team === 0 ? homeChasers : awayChasers;
      const isPressing = chasers.some((candidate) => candidate.id === player.id) && !latestOwner?.keeper;
      if (isPressing && latestOwner?.team !== player.team) {
        targetX = ball.x - teamDirection * (player.role === "ST" ? 2.5 : 1.2);
        targetZ = ball.z + (player === chasers[0] ? 0 : player.baseZ > ball.z ? 1.8 : -1.8);
        pace = 6.1;
      } else {
        targetX = player.baseX + (ball.x - player.baseX) * (latestOwner ? 0.16 : 0.28);
        targetZ = player.baseZ + clamp((ball.z - player.baseZ) * 0.22, -7.2, 7.2);
      }
    }

    if (player.team === 1) pace *= state.difficulty === "WORLD CLASS" ? 1.12 : state.difficulty === "CASUAL" ? 0.78 : 1;
    if (state.mode === "TRAINING" && player.team === 1) pace *= 0.68;
    moveToward(player, targetX, targetZ, pace, dt);
  });

  const activeOwner = playerById(state, ball.ownerId);
  if (activeOwner) {
    const direction = activeOwner.team === 0 ? 1 : -1;
    if (activeOwner.id !== state.selectedId) {
      const distanceToGoal = Math.abs(direction * GOAL_X - activeOwner.x);
      const pressureRadius = state.difficulty === "WORLD CLASS" ? 3.8 : state.difficulty === "CASUAL" ? 2.8 : 3.4;
      const pressured = state.players.some((player) => player.team !== activeOwner.team && Math.hypot(player.x - activeOwner.x, player.z - activeOwner.z) < pressureRadius);
      if (state.aiCooldown <= 0) {
        const roll = nextRandom(state);
        const shotRange = state.difficulty === "WORLD CLASS" ? 29 : state.difficulty === "CASUAL" ? 20 : 25;
        const shotIntent = state.difficulty === "WORLD CLASS" ? 0.58 : state.difficulty === "CASUAL" ? 0.28 : 0.43;
        if (distanceToGoal < shotRange && (pressured || roll < shotIntent)) {
          shootBall(state, activeOwner);
          state.aiCooldown = 1.15;
        } else if (pressured || (state.possessionTime > (state.difficulty === "WORLD CLASS" ? 1.55 : 2.1) && roll < 0.42)) {
          passBall(state, activeOwner, state.possessionTime > 1.25 && roll > 0.58);
          state.aiCooldown = 1.35 + nextRandom(state) * 0.9;
        } else {
          state.aiCooldown = 0.5 + nextRandom(state) * 0.7;
        }
      }
    }
    const liveOwner = playerById(state, ball.ownerId);
    if (liveOwner) {
      const angle = liveOwner.angle;
      ball.x = liveOwner.x + Math.sin(angle) * 0.7;
      ball.y = 0.23 + Math.max(0, Math.sin(state.elapsed * 12)) * 0.025;
      ball.z = liveOwner.z + Math.cos(angle) * 0.7;
      ball.vx = liveOwner.vx;
      ball.vz = liveOwner.vz;
      ball.vy = 0;
      state.possessionTime += dt;
    }
  } else {
    ball.kickAge += dt;
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;
    ball.z += ball.vz * dt;
    ball.vy -= 9.8 * dt;
    if (ball.y < 0.23) {
      ball.y = 0.23;
      if (Math.abs(ball.vy) > 1.05) ball.vy = -ball.vy * 0.33;
      else ball.vy = 0;
      ball.vx *= 0.982;
      ball.vz *= 0.982;
    }
    const airDrag = Math.max(0, 1 - dt * 0.09);
    ball.vx *= airDrag;
    ball.vz *= airDrag;
    if (ball.passTargetId && ball.kickAge > 0.12) {
      const receiver = playerById(state, ball.passTargetId);
      if (receiver && Math.hypot(receiver.x - ball.x, receiver.z - ball.z) < 1.45 && ball.y < 1.45) {
        ball.ownerId = receiver.id;
        ball.passTargetId = null;
        ball.vx = receiver.vx;
        ball.vy = 0;
        ball.vz = receiver.vz;
        state.possessionTime = 0;
      }
    }
    if (!ball.ownerId && ball.kickAge > 0.12 && ball.y < 2.45) {
      const keeper = state.players.find((player) => {
        if (!player.keeper) return false;
        const headingToGoal = player.team === 0 ? ball.vx < 0 : ball.vx > 0;
        const crossedLine = player.team === 0 ? ball.x <= -48.4 && ball.x > -50.2 : ball.x >= 48.4 && ball.x < 50.2;
        return headingToGoal && crossedLine && Math.abs(ball.z - player.z) < 1.85;
      });
      if (keeper) {
        const goalDirection = keeper.team === 0 ? -1 : 1;
        ball.x = goalDirection * 47.9;
        ball.vx = -ball.vx * 0.38;
        ball.vy = Math.max(1.3, Math.abs(ball.vy) * 0.52);
        ball.vz *= -0.28;
        ball.passTargetId = null;
        ball.kickAge = 0;
        keeper.actionUntil = 0.82;
        keeper.vz += Math.sign(ball.z - keeper.z || 1) * 2.8;
        setEvent(state, "SAVE", 1.25);
      }
    }
    if (!ball.ownerId && ball.kickAge > 0.22 && ball.y < 1.15 && Math.hypot(ball.vx, ball.vz) < 17) {
      const receiver = state.players
        .filter((player) => !player.keeper)
        .map((player) => ({ player, distance: Math.hypot(player.x - ball.x, player.z - ball.z) }))
        .sort((a, b) => a.distance - b.distance)[0];
      if (receiver && receiver.distance < 0.92) {
        ball.ownerId = receiver.player.id;
        ball.passTargetId = null;
        state.possessionTime = 0;
      }
    }
  }

  if (Math.abs(ball.x) >= GOAL_X && ball.y < 2.45 && Math.abs(ball.z) <= GOAL_HALF_WIDTH) {
    registerGoal(state, ball.x > 0 ? 0 : 1);
  } else if (Math.abs(ball.x) > FIELD_X + 3 || Math.abs(ball.z) > FIELD_Z + 2) {
    const team = state.players.find((player) => player.id === state.selectedId)?.team ?? 0;
    state.ball.ownerId = null;
    state.ball.passTargetId = null;
    state.ball.x = clamp(ball.x, -FIELD_X + 2, FIELD_X - 2);
    state.ball.z = clamp(ball.z, -FIELD_Z + 2, FIELD_Z - 2);
    state.ball.vx = 0;
    state.ball.vy = 0;
    state.ball.vz = 0;
    const restart = state.players.find((player) => player.team === team && !player.keeper && Math.hypot(player.x - ball.x, player.z - ball.z) < 8);
    if (restart) {
      state.ball.ownerId = restart.id;
      setEvent(state, "RESTART", 1.1);
    }
  }

  input.pressed.clear();
}

function applyFormation(state: MatchState, formation: Formation) {
  state.formation = formation;
  state.players.forEach((player) => {
    const [, x, z] = LINEUPS[formation][Number(player.id.split("-")[1])];
    player.role = LINEUPS[formation][Number(player.id.split("-")[1])][0];
    player.baseX = player.team === 0 ? x : -x;
    player.baseZ = z;
    player.x = player.baseX;
    player.z = player.baseZ;
    player.vx = 0;
    player.vz = 0;
  });
}

export function setFormation(state: MatchState, formation: Formation) {
  applyFormation(state, formation);
  if (state.mode === "PENALTIES") setupPenalty(state, state.penaltyTeam);
  else {
    state.ball.ownerId = null;
    setKickoff(state, state.pendingKickoffTeam);
  }
}

export function tickMatch(state: MatchState, input: InputState, delta: number) {
  const dt = Math.min(delta, 0.04);
  state.players.forEach((player) => {
    player.actionUntil = Math.max(0, player.actionUntil - dt);
  });
  if (state.mode === "PENALTIES") updatePenalty(state, input, dt);
  else updateMatch(state, input, dt);
}

export function readSnapshot(state: MatchState): MatchSnapshot {
  const selected = playerById(state, state.selectedId);
  const owner = playerById(state, state.ball.ownerId);
  return {
    score: [...state.score],
    elapsed: state.elapsed,
    selectedId: state.selectedId,
    playerName: selected?.name ?? "M. Wells",
    playerRole: selected?.role ?? "CM",
    stamina: selected?.stamina ?? 100,
    event: state.eventTime > 0 ? state.event : "",
    mode: state.mode,
    possession: owner?.team ?? null,
    penaltyTeam: state.penaltyTeam,
    penaltyAttempts: [...state.penaltyAttempts],
    penaltyAimZ: state.penaltyAimZ,
    finished: state.finished,
  };
}