import { memo, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { GraphicsQuality, Player, TeamDefinition } from "./types";

type PlayerAvatarProps = {
  player: Player;
  team: TeamDefinition;
  selected: boolean;
  quality?: GraphicsQuality;
};

export const PlayerAvatar = memo(function PlayerAvatar({ player, team, selected, quality = "HIGH" }: PlayerAvatarProps) {
  const detailed = quality === "HIGH";
  const trimmed = quality !== "PERFORMANCE";
  const root = useRef<THREE.Group>(null);
  const body = useRef<THREE.Group>(null);
  const leftLeg = useRef<THREE.Group>(null);
  const rightLeg = useRef<THREE.Group>(null);
  const leftShin = useRef<THREE.Group>(null);
  const rightShin = useRef<THREE.Group>(null);
  const leftArm = useRef<THREE.Group>(null);
  const rightArm = useRef<THREE.Group>(null);
  const selectionRing = useRef<THREE.Mesh>(null);
  const kitColor = player.keeper ? team.colors.keeper : team.colors.kit;
  const trimColor = player.keeper ? team.colors.keeperTrim : team.colors.trim;
  const jersey = useMemo(() => new THREE.MeshStandardMaterial({ color: kitColor, roughness: 0.67, metalness: 0.045, emissive: kitColor, emissiveIntensity: 0.15 }), [kitColor]);
  const trim = useMemo(() => new THREE.MeshStandardMaterial({ color: trimColor, roughness: 0.62, metalness: 0.1 }), [trimColor]);
  const shorts = useMemo(() => new THREE.MeshStandardMaterial({ color: player.keeper ? team.colors.keeper : team.colors.shorts, roughness: 0.78 }), [player.keeper, team.colors.keeper, team.colors.shorts]);
  const socks = useMemo(() => new THREE.MeshStandardMaterial({ color: player.keeper ? team.colors.keeper : team.colors.socks, roughness: 0.84 }), [player.keeper, team.colors.keeper, team.colors.socks]);
  const skin = useMemo(() => new THREE.MeshStandardMaterial({ color: player.skin, roughness: 0.76 }), [player.skin]);
  const hair = useMemo(() => new THREE.MeshStandardMaterial({ color: player.hair, roughness: 0.88 }), [player.hair]);
  const boot = useMemo(() => new THREE.MeshStandardMaterial({ color: player.number % 3 === 0 ? "#f0c667" : "#1a2525", roughness: 0.52, metalness: 0.08 }), [player.number]);
  const eye = useMemo(() => new THREE.MeshStandardMaterial({ color: "#24201d", roughness: 0.9 }), []);

  useFrame(({ clock }) => {
    if (!root.current || !body.current) return;
    const time = clock.elapsedTime;
    const speed = Math.hypot(player.vx, player.vz);
    const stride = Math.min(1, speed / 5.5);
    const cycle = time * (6 + stride * 7) + player.number * 0.31;
    const kick = player.actionUntil > 0 ? Math.sin((1 - player.actionUntil / 0.38) * Math.PI) : 0;
    const dive = player.keeper && player.actionUntil > 0 ? Math.sin((1 - player.actionUntil) * Math.PI * 0.78) : 0;
    root.current.visible = player.visible;
    root.current.position.set(player.x, 0, player.z);
    root.current.rotation.y = player.angle;
    root.current.rotation.z = dive * Math.sign(player.vz || 1) * 0.55;
    root.current.scale.set(player.build, player.height, player.build);
    body.current.position.y = 0.025 + Math.abs(Math.sin(cycle)) * 0.035 * stride - dive * 0.08;
    body.current.rotation.x = -0.05 - stride * 0.12;
    body.current.rotation.z = dive * Math.sign(player.vz || 1) * 0.2;
    if (leftLeg.current) leftLeg.current.rotation.x = Math.sin(cycle) * 0.62 * stride;
    if (rightLeg.current) rightLeg.current.rotation.x = Math.sin(cycle + Math.PI) * 0.62 * stride + kick * 0.95;
    if (leftShin.current) leftShin.current.rotation.x = Math.max(0, -Math.sin(cycle + 0.65)) * 0.7 * stride;
    if (rightShin.current) rightShin.current.rotation.x = Math.max(0, -Math.sin(cycle + Math.PI + 0.65)) * 0.7 * stride - kick * 0.4;
    if (leftArm.current) leftArm.current.rotation.x = Math.sin(cycle + Math.PI) * 0.4 * stride;
    if (rightArm.current) rightArm.current.rotation.x = Math.sin(cycle) * 0.4 * stride;
    if (selectionRing.current) {
      const material = selectionRing.current.material as THREE.MeshBasicMaterial;
      material.opacity = 0.72 + Math.sin(time * 3.1) * 0.2;
    }
  });

  return (
    <group ref={root} visible={player.visible}>
      {selected && (
        <mesh ref={selectionRing} position={[0, 0.045, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.39, 0.46, 42]} />
          <meshBasicMaterial color="#d4ff70" transparent opacity={0.86} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
      )}
      <group ref={body}>
        <mesh position={[0, 1.41, 0]} scale={[0.34, 0.42, 0.235]} castShadow receiveShadow material={jersey}>
          <sphereGeometry args={[1, 20, 16]} />
        </mesh>
        <mesh position={[0, 1.69, 0]} scale={[0.34, 0.12, 0.24]} castShadow material={jersey}>
          <sphereGeometry args={[1, 16, 10]} />
        </mesh>
        {trimmed && (
          <>
            <mesh position={[0, 1.59, 0.211]} castShadow material={trim}>
              <boxGeometry args={[0.055, 0.34, 0.018]} />
            </mesh>
            <mesh position={[-0.11, 1.55, 0.215]} material={trim}>
              <boxGeometry args={[0.035, 0.32, 0.015]} />
            </mesh>
            <mesh position={[0.11, 1.55, 0.215]} material={trim}>
              <boxGeometry args={[0.035, 0.32, 0.015]} />
            </mesh>
          </>
        )}
        <mesh position={[0, 1.08, 0]} scale={[0.29, 0.21, 0.215]} castShadow material={shorts}>
          <sphereGeometry args={[1, 16, 12]} />
        </mesh>
        {trimmed && (
          <>
            <mesh position={[-0.276, 1.07, 0]} material={trim}>
              <boxGeometry args={[0.025, 0.19, 0.08]} />
            </mesh>
            <mesh position={[0.276, 1.07, 0]} material={trim}>
              <boxGeometry args={[0.025, 0.19, 0.08]} />
            </mesh>
          </>
        )}
        <mesh position={[0, 1.78, 0]} castShadow material={skin}>
          <cylinderGeometry args={[0.095, 0.12, 0.2, 10]} />
        </mesh>
        <mesh position={[0, 1.98, 0.01]} castShadow receiveShadow material={skin}>
          <sphereGeometry args={[0.19, 18, 14]} />
        </mesh>
        <mesh position={[0, 2.065, -0.025]} scale={[0.194, player.hairStyle === 2 ? 0.09 : 0.115, 0.194]} castShadow material={hair}>
          <sphereGeometry args={[1, 16, 10]} />
        </mesh>
        {player.hairStyle === 1 && (
          <mesh position={[0, 2.04, -0.04]} scale={[0.21, 0.12, 0.205]} castShadow material={hair}>
            <sphereGeometry args={[1, 12, 9]} />
          </mesh>
        )}
        {player.hairStyle === 3 && (
          <mesh position={[0, 2.1, -0.015]} rotation={[0.18, 0, 0]} scale={[0.16, 0.14, 0.19]} castShadow material={hair}>
            <coneGeometry args={[1, 0.38, 8]} />
          </mesh>
        )}
        {detailed && [-1, 1].map((side) => (
          <group key={`ear-${side}`}>
            <mesh position={[side * 0.179, 1.98, 0]} scale={[0.045, 0.065, 0.05]} material={skin}><sphereGeometry args={[1, 8, 7]} /></mesh>
            <mesh position={[side * 0.066, 1.99, 0.17]} material={eye}><sphereGeometry args={[0.022, 8, 6]} /></mesh>
            <mesh position={[side * 0.066, 2.025, 0.166]} rotation={[0, 0, side * -0.12]} material={hair}><boxGeometry args={[0.054, 0.015, 0.018]} /></mesh>
          </group>
        ))}
        {detailed && (
          <>
            <mesh position={[0, 1.915, 0.188]} scale={[0.04, 0.05, 0.045]} material={skin}><sphereGeometry args={[1, 8, 7]} /></mesh>
            <mesh position={[0, 1.84, 0.183]} scale={[0.05, 0.012, 0.008]} material={eye}><sphereGeometry args={[1, 8, 6]} /></mesh>
          </>
        )}
        {trimmed && (
          <mesh position={[0, 1.73, 0.13]} rotation={[0, 0, Math.PI / 2]} material={trim}>
            <torusGeometry args={[0.095, 0.025, 6, 14]} />
          </mesh>
        )}
        <group ref={leftArm} position={[-0.32, 1.56, 0]}>
          <mesh position={[-0.045, -0.19, 0]} rotation={[0, 0, 0.12]} castShadow material={jersey}>
            <capsuleGeometry args={[0.12, 0.24, 3, 7]} />
          </mesh>
          <mesh position={[-0.06, -0.39, 0.01]} rotation={[0, 0, 0.08]} castShadow material={skin}>
            <capsuleGeometry args={[0.075, 0.24, 3, 7]} />
          </mesh>
          <mesh position={[-0.07, -0.55, 0.02]} material={skin}>
            <sphereGeometry args={[0.082, 8, 7]} />
          </mesh>
        </group>
        <group ref={rightArm} position={[0.32, 1.56, 0]}>
          <mesh position={[0.045, -0.19, 0]} rotation={[0, 0, -0.12]} castShadow material={jersey}>
            <capsuleGeometry args={[0.12, 0.24, 3, 7]} />
          </mesh>
          <mesh position={[0.06, -0.39, 0.01]} rotation={[0, 0, -0.08]} castShadow material={skin}>
            <capsuleGeometry args={[0.075, 0.24, 3, 7]} />
          </mesh>
          <mesh position={[0.07, -0.55, 0.02]} material={skin}>
            <sphereGeometry args={[0.082, 8, 7]} />
          </mesh>
        </group>
        <group ref={leftLeg} position={[-0.14, 1.0, 0]}>
          <mesh position={[0, -0.22, 0]} castShadow material={shorts}>
            <capsuleGeometry args={[0.115, 0.24, 3, 7]} />
          </mesh>
          <group ref={leftShin} position={[0, -0.47, 0]}>
            <mesh position={[0, -0.21, 0]} castShadow material={socks}>
              <capsuleGeometry args={[0.075, 0.28, 3, 7]} />
            </mesh>
            {trimmed && (
              <mesh position={[0, -0.4, 0.035]} material={trim}>
                <torusGeometry args={[0.076, 0.022, 5, 10]} />
              </mesh>
            )}
            <mesh position={[0, -0.43, 0.095]} scale={[0.105, 0.085, 0.19]} rotation={[-0.08, 0, 0]} castShadow material={boot}>
              <sphereGeometry args={[1, 12, 8]} />
            </mesh>
            {detailed && [0, 1, 2].map((index) => <mesh key={index} position={[0, -0.5, 0.02 + index * 0.055]} material={trim}><boxGeometry args={[0.07, 0.012, 0.014]} /></mesh>)}
          </group>
        </group>
        <group ref={rightLeg} position={[0.14, 1.0, 0]}>
          <mesh position={[0, -0.22, 0]} castShadow material={shorts}>
            <capsuleGeometry args={[0.115, 0.24, 3, 7]} />
          </mesh>
          <group ref={rightShin} position={[0, -0.47, 0]}>
            <mesh position={[0, -0.21, 0]} castShadow material={socks}>
              <capsuleGeometry args={[0.075, 0.28, 3, 7]} />
            </mesh>
            {trimmed && (
              <mesh position={[0, -0.4, 0.035]} material={trim}>
                <torusGeometry args={[0.076, 0.022, 5, 10]} />
              </mesh>
            )}
            <mesh position={[0, -0.43, 0.095]} scale={[0.105, 0.085, 0.19]} rotation={[-0.08, 0, 0]} castShadow material={boot}>
              <sphereGeometry args={[1, 12, 8]} />
            </mesh>
            {detailed && [0, 1, 2].map((index) => <mesh key={index} position={[0, -0.5, 0.02 + index * 0.055]} material={trim}><boxGeometry args={[0.07, 0.012, 0.014]} /></mesh>)}
          </group>
        </group>
      </group>
    </group>
  );
});