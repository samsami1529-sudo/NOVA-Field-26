import type { TeamDefinition } from "./types";

export const TEAMS: TeamDefinition[] = [
  {
    id: "vesper",
    name: "Vesper City",
    short: "VSC",
    city: "Vesper",
    colors: {
      kit: "#1d6153",
      trim: "#d2ff79",
      shorts: "#163a32",
      socks: "#d5efb0",
      keeper: "#e8bf48",
      keeperTrim: "#152d2b",
    },
  },
  {
    id: "montreux",
    name: "Montreux FC",
    short: "MTX",
    city: "Montreux",
    colors: {
      kit: "#c74c3f",
      trim: "#f8dfbc",
      shorts: "#35272d",
      socks: "#e7d8ca",
      keeper: "#5273a3",
      keeperTrim: "#e9d78c",
    },
  },
  {
    id: "rover",
    name: "Rover Athletic",
    short: "RVA",
    city: "Briston",
    colors: {
      kit: "#d7d7d0",
      trim: "#1c3c70",
      shorts: "#18345e",
      socks: "#d8d5c8",
      keeper: "#bd6286",
      keeperTrim: "#f7d876",
    },
  },
  {
    id: "monaco",
    name: "Monaco Vale",
    short: "MCV",
    city: "Monaco",
    colors: {
      kit: "#e6b849",
      trim: "#263d62",
      shorts: "#202e48",
      socks: "#ead89e",
      keeper: "#55a79f",
      keeperTrim: "#f7eee0",
    },
  },
];

export const DEFAULT_HOME = TEAMS[0];
export const DEFAULT_AWAY = TEAMS[1];