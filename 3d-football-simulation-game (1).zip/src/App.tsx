import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  ChevronDown,
  ChevronRight,
  CloudRain,
  Compass,
  Crosshair,
  Download,
  Gauge,
  LayoutGrid,
  LoaderCircle,
  Moon,
  Pause,
  Play,
  RotateCcw,
  RotateCw,
  Settings2,
  Shield,
  Shirt,
  Smartphone,
  Sun,
  Target,
  Trophy,
  Users,
  Wind,
  X,
  Zap,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { Canvas } from "@react-three/fiber";
import { createMatch, readSnapshot, setFormation } from "./game/simulation";
import { MatchScene } from "./game/MatchScene";
import { DEFAULT_AWAY, DEFAULT_HOME, TEAMS } from "./game/teams";
import { useGyroscope } from "./game/useGyroscope";
import type { CameraStyle, Formation, GameMode, GraphicsQuality, InputState, MatchSnapshot, MatchState, TeamDefinition, TimeOfDay, Weather } from "./game/types";

type Panel = "MENU" | "MODES" | "SQUAD" | "SETTINGS" | null;

const DEFAULT_QUALITY: GraphicsQuality = typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
  ? "PERFORMANCE"
  : "HIGH";

const QUALITY_CONFIG: Record<GraphicsQuality, { dpr: [number, number]; shadows: boolean; antialias: boolean }> = {
  PERFORMANCE: { dpr: [0.9, 1], shadows: false, antialias: false },
  BALANCED: { dpr: [1, 1.3], shadows: true, antialias: true },
  HIGH: { dpr: [1, 1.75], shadows: true, antialias: true },
};

const MODE_OPTIONS: Array<{ mode: GameMode; title: string; description: string; icon: typeof LayoutGrid }> = [
  { mode: "KICK OFF", title: "Kick Off", description: "A straight-up match under the lights.", icon: Play },
  { mode: "CAREER", title: "Career", description: "Take your club into a new season.", icon: Activity },
  { mode: "TOURNAMENT", title: "Tournament", description: "Start a knockout run. Every goal matters.", icon: Trophy },
  { mode: "TRAINING", title: "Training", description: "Open play with space to find your rhythm.", icon: Target },
  { mode: "PENALTIES", title: "Penalty Shootout", description: "One taker. One keeper. Make it count.", icon: Crosshair },
];

const FORMATIONS: Formation[] = ["4-3-3", "4-2-3-1", "3-5-2"];
const GAME_KEYS = new Set([
  "KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight",
  "ShiftLeft", "ShiftRight", "KeyJ", "KeyK", "KeyL", "KeyQ", "Tab", "Enter",
]);

function TeamCrest({ team, small = false }: { team: TeamDefinition; small?: boolean }) {
  return (
    <span className={`team-crest${small ? " team-crest-small" : ""}`} style={{ "--crest-color": team.colors.trim, "--crest-kit": team.colors.kit } as CSSProperties} aria-hidden="true">
      <svg viewBox="0 0 40 46" fill="none">
        <path d="M4 5.5 20 2l16 3.5v18.4c0 8.5-6.8 15.6-16 20.1C10.8 39.5 4 32.4 4 23.9V5.5Z" fill="var(--crest-kit)" stroke="var(--crest-color)" strokeWidth="2.3" />
        <path d="m12 15.5 8-3 8 3-2.3 10.8L20 32l-5.7-5.7L12 15.5Z" fill="var(--crest-color)" />
        <path d="m16.2 19.4 3.8-1.5 3.8 1.5-1.1 5.1-2.7 2.6-2.7-2.6-1.1-5.1Z" fill="var(--crest-kit)" />
      </svg>
    </span>
  );
}

function formattedClock(elapsed: number, mode: GameMode) {
  if (mode === "PENALTIES") return "PEN";
  const seconds = Math.floor(elapsed * 45);
  const minutes = Math.min(90, Math.floor(seconds / 60));
  const remaining = seconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(remaining).padStart(2, "0")}`;
}

function Scoreboard({ snapshot, home, away }: { snapshot: MatchSnapshot; home: TeamDefinition; away: TeamDefinition }) {
  const homeScore = snapshot.score[0];
  const awayScore = snapshot.score[1];
  return (
    <div className="scoreboard" aria-label={`${home.name} ${homeScore}, ${away.name} ${awayScore}`}>
      <div className="score-team score-team-home">
        <TeamCrest team={home} small />
        <span className="score-team-name">{home.short}</span>
      </div>
      <div className="score-center">
        <div className="score-numbers">
          <motion.span key={`home-${homeScore}`} initial={{ y: -5, opacity: 0.45 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.22 }}>{homeScore}</motion.span>
          <i>:</i>
          <motion.span key={`away-${awayScore}`} initial={{ y: -5, opacity: 0.45 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.22 }}>{awayScore}</motion.span>
        </div>
        <div className={`score-clock${snapshot.mode === "PENALTIES" ? " score-clock-pen" : ""}`}>
          {snapshot.mode === "PENALTIES" ? `${snapshot.penaltyAttempts[snapshot.penaltyTeam] + 1} / 5` : formattedClock(snapshot.elapsed, snapshot.mode)}
        </div>
      </div>
      <div className="score-team score-team-away">
        <span className="score-team-name">{away.short}</span>
        <TeamCrest team={away} small />
      </div>
      <div className="score-live"><span /> LIVE</div>
    </div>
  );
}

function KeyHint({ keys, label }: { keys: string[]; label: string }) {
  return (
    <div className="key-hint">
      <span className="key-group">{keys.map((key) => <kbd key={key}>{key}</kbd>)}</span>
      <span>{label}</span>
    </div>
  );
}

function TeamSelect({ label, value, onChange }: { label: string; value: string; onChange: (id: string) => void }) {
  const selected = TEAMS.find((team) => team.id === value) ?? TEAMS[0];
  return (
    <label className="team-select">
      <span className="field-label">{label}</span>
      <span className="team-select-control">
        <TeamCrest team={selected} small />
        <select value={value} onChange={(event) => onChange(event.target.value)}>
          {TEAMS.map((team) => <option key={team.id} value={team.id}>{team.name}</option>)}
        </select>
        <ChevronDown size={15} aria-hidden="true" />
      </span>
    </label>
  );
}

function TouchControls({ press, release, penalties }: { press: (code: string) => void; release: (code: string) => void; penalties: boolean }) {
  const touchButton = (code: string, label: string, icon: ReactNode, className = "") => (
    <button
      key={code}
      className={`touch-button ${className}`}
      type="button"
      aria-label={label}
      onContextMenu={(event) => event.preventDefault()}
      onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); press(code); }}
      onPointerUp={() => release(code)}
      onPointerCancel={() => release(code)}
      onLostPointerCapture={() => release(code)}
    >
      {icon}<span>{label}</span>
    </button>
  );

  return (
    <div className="touch-controls" aria-label="Touch controls">
      <div className="touch-dpad">
        {touchButton("KeyW", penalties ? "Higher" : "Forward", <ArrowUp size={17} />, "dpad-up")}
        {touchButton("KeyA", penalties ? "Aim left" : "Left", <ArrowLeft size={17} />, "dpad-left")}
        {touchButton("KeyD", penalties ? "Aim right" : "Right", <ArrowRight size={17} />, "dpad-right")}
        {touchButton("KeyS", penalties ? "Lower" : "Back", <ArrowDown size={17} />, "dpad-down")}
      </div>
      <div className={`touch-actions${penalties ? " penalties-actions" : ""}`}>
        {touchButton("KeyK", "Shoot", <Target size={17} />, "touch-shoot")}
        {!penalties && touchButton("KeyJ", "Pass", <ChevronRight size={17} />, "touch-pass")}
        {!penalties && touchButton("KeyL", "Through", <Zap size={17} />, "touch-through")}
        {!penalties && touchButton("ShiftLeft", "Sprint", <Wind size={17} />, "touch-sprint")}
      </div>
    </div>
  );
}

function PanelHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <div className="panel-heading">
      <div className="panel-eyebrow"><span />{eyebrow}</div>
      <h2>{title}</h2>
      <p>{description}</p>
    </div>
  );
}

function App() {
  const matchRef = useRef<MatchState>(createMatch("KICK OFF", DEFAULT_HOME, DEFAULT_AWAY));
  const inputRef = useRef<InputState>({ down: new Set(), pressed: new Set() });
  const panelRef = useRef<Panel>(null);
  const [snapshot, setSnapshot] = useState<MatchSnapshot>(() => readSnapshot(matchRef.current));
  const [panel, setPanel] = useState<Panel>(null);
  const [selectedMode, setSelectedMode] = useState<GameMode>("KICK OFF");
  const [homeId, setHomeId] = useState(DEFAULT_HOME.id);
  const [awayId, setAwayId] = useState(DEFAULT_AWAY.id);
  const [matchHomeId, setMatchHomeId] = useState(DEFAULT_HOME.id);
  const [matchAwayId, setMatchAwayId] = useState(DEFAULT_AWAY.id);
  const [weather, setWeather] = useState<Weather>("CLEAR");
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>("NIGHT");
  const [cameraStyle, setCameraStyle] = useState<CameraStyle>("BROADCAST");
  const [cameraZoom, setCameraZoom] = useState(1);
  const [quality, setQuality] = useState<GraphicsQuality>(DEFAULT_QUALITY);
  const [gyroSensitivity, setGyroSensitivity] = useState(1);
  const gyro = useGyroscope(gyroSensitivity);
  const [difficulty, setDifficulty] = useState<MatchState["difficulty"]>("COMPETITIVE");
  const [revision, setRevision] = useState(0);
  const home = useMemo(() => TEAMS.find((team) => team.id === matchHomeId) ?? DEFAULT_HOME, [matchHomeId]);
  const away = useMemo(() => TEAMS.find((team) => team.id === matchAwayId) ?? DEFAULT_AWAY, [matchAwayId]);
  const selectedHome = useMemo(() => TEAMS.find((team) => team.id === homeId) ?? DEFAULT_HOME, [homeId]);
  const selectedAway = useMemo(() => TEAMS.find((team) => team.id === awayId) ?? DEFAULT_AWAY, [awayId]);
  panelRef.current = panel;

  const onSnapshot = useCallback((next: MatchSnapshot) => setSnapshot(next), []);

  useEffect(() => {
    const keyDown = (event: KeyboardEvent) => {
      if (event.code === "Escape") {
        event.preventDefault();
        setPanel((current) => current ? null : "MENU");
        return;
      }
      if (panelRef.current || !GAME_KEYS.has(event.code)) return;
      event.preventDefault();
      const input = inputRef.current;
      if (!input.down.has(event.code)) input.pressed.add(event.code);
      input.down.add(event.code);
    };
    const keyUp = (event: KeyboardEvent) => {
      inputRef.current.down.delete(event.code);
    };
    const clearInput = () => {
      inputRef.current.down.clear();
      inputRef.current.pressed.clear();
    };
    window.addEventListener("keydown", keyDown);
    window.addEventListener("keyup", keyUp);
    window.addEventListener("blur", clearInput);
    return () => {
      window.removeEventListener("keydown", keyDown);
      window.removeEventListener("keyup", keyUp);
      window.removeEventListener("blur", clearInput);
    };
  }, []);

  const showPanel = (next: Exclude<Panel, null>) => {
    inputRef.current.down.clear();
    inputRef.current.pressed.clear();
    setPanel(next);
  };

  const resumeMatch = () => {
    inputRef.current.pressed.clear();
    setPanel(null);
  };

  const startMatch = () => {
    const next = createMatch(selectedMode, selectedHome, selectedAway);
    next.difficulty = difficulty;
    matchRef.current = next;
    setMatchHomeId(homeId);
    setMatchAwayId(awayId);
    setRevision((value) => value + 1);
    setSnapshot(readSnapshot(next));
    setPanel(null);
    inputRef.current.down.clear();
    inputRef.current.pressed.clear();
  };

  const changeFormation = (formation: Formation) => {
    setFormation(matchRef.current, formation);
    setSnapshot(readSnapshot(matchRef.current));
  };

  const selectPlayer = (id: string) => {
    if (matchRef.current.mode === "PENALTIES") return;
    matchRef.current.selectedId = id;
    setSnapshot(readSnapshot(matchRef.current));
  };

  const press = (code: string) => {
    const input = inputRef.current;
    if (!input.down.has(code)) input.pressed.add(code);
    input.down.add(code);
  };
  const release = (code: string) => inputRef.current.down.delete(code);

  const selectedPlayer = matchRef.current.players.find((player) => player.id === snapshot.selectedId);
  const isPaused = panel !== null;
  const activeMode = MODE_OPTIONS.find((item) => item.mode === selectedMode) ?? MODE_OPTIONS[0];
  const qualityConfig = QUALITY_CONFIG[quality];
  const changeZoom = (amount: number) => setCameraZoom((value) => Math.min(1.55, Math.max(0.72, Number((value + amount).toFixed(2)))));

  return (
    <main className="game-shell">
      <div className="stadium-canvas">
        <Canvas
          shadows={qualityConfig.shadows}
          dpr={qualityConfig.dpr}
          camera={{ position: [-10.4, 10.8, 6.4], fov: 52, near: 0.1, far: 760 }}
          gl={{ antialias: qualityConfig.antialias, alpha: false, powerPreference: "high-performance", stencil: false }}
          onCreated={({ gl }) => {
            gl.toneMapping = 4;
            gl.toneMappingExposure = 1.08;
            gl.shadowMap.enabled = qualityConfig.shadows;
          }}
        >
          <MatchScene
            key={revision}
            matchRef={matchRef}
            inputRef={inputRef}
            teams={[home, away]}
            weather={weather}
            timeOfDay={timeOfDay}
            paused={isPaused}
            cameraStyle={cameraStyle}
            cameraZoom={cameraZoom}
            quality={quality}
            gyroEnabled={gyro.enabled}
            gyroYawRef={gyro.yawRef}
            gyroPitchRef={gyro.pitchRef}
            onSnapshot={onSnapshot}
          />
        </Canvas>
      </div>
      <div className="scene-shade" />
      <div className="orientation-hint"><RotateCw size={13} /> ROTATE TO LANDSCAPE FOR THE FULL TOUCH LAYOUT</div>

      <motion.header className="top-hud" initial={{ y: -18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}>
        <div className="brand-lockup">
          <div className="brand-emblem"><span>N</span><i /></div>
          <div className="brand-type">
            <div className="brand-name">NOVA<span> / </span>FIELD</div>
            <div className="brand-subtitle">FOOTBALL SIMULATION <b>26</b></div>
          </div>
        </div>

        <Scoreboard snapshot={snapshot} home={home} away={away} />

        <nav className="hud-actions" aria-label="Match tools">
          <button className="hud-tool" type="button" onClick={() => showPanel("SQUAD")} aria-label="Open team sheet">
            <Users size={17} /><span>TEAM</span>
          </button>
          <button className="hud-tool" type="button" onClick={() => showPanel("SETTINGS")} aria-label="Open match settings">
            <Settings2 size={17} /><span>SETTINGS</span>
          </button>
          <button className="pause-button" type="button" onClick={() => showPanel("MENU")} aria-label="Pause match">
            <Pause size={17} /><span>PAUSE</span>
          </button>
        </nav>
      </motion.header>

      <div className="broadcast-mark"><span className="broadcast-dot" />NOVA ARENA <i>/</i> BROADCAST CAM 01</div>

      <AnimatePresence mode="wait">
        {snapshot.event && !isPaused && (
          <motion.div
            key={snapshot.event}
            className={`match-event${snapshot.event === "GOAL" ? " match-event-goal" : ""}`}
            initial={{ opacity: 0, y: 11, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -5, scale: 0.98 }}
            transition={{ duration: 0.24 }}
          >
            <span className="event-spark">{snapshot.event === "GOAL" ? <Trophy size={16} /> : <Activity size={15} />}</span>
            <span>{snapshot.event}</span>
            <i />
          </motion.div>
        )}
      </AnimatePresence>

      <motion.footer className="bottom-hud" initial={{ y: 14, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.7, delay: 0.16 }}>
        <div className="active-player">
          <div className="player-shirt"><Shirt size={18} /><span>{selectedPlayer?.number ?? 9}</span></div>
          <div className="player-readout">
            <div className="player-name-line"><span>{snapshot.playerName}</span><i>{snapshot.playerRole}</i></div>
            <div className="stamina-line"><span>STAMINA</span><div className="stamina-track"><i style={{ width: `${Math.max(3, snapshot.stamina)}%` }} /></div></div>
          </div>
        </div>

        <div className="desktop-controls" aria-label="Keyboard controls">
          {snapshot.mode === "PENALTIES" ? (
            <>
              <KeyHint keys={["A", "D"]} label="AIM" />
              <KeyHint keys={["W", "S"]} label="HEIGHT" />
              <KeyHint keys={["K"]} label="SHOOT" />
            </>
          ) : (
            <>
              <KeyHint keys={["W", "A", "S", "D"]} label="MOVE" />
              <KeyHint keys={["SHIFT"]} label="SPRINT" />
              <KeyHint keys={["J"]} label="PASS" />
              <KeyHint keys={["L"]} label="THROUGH" />
              <KeyHint keys={["K"]} label="SHOOT" />
              <KeyHint keys={["Q"]} label="TACKLE" />
              <KeyHint keys={["TAB"]} label="SWITCH" />
            </>
          )}
        </div>

        <div className="bottom-tools">
          <div className="zoom-quick" aria-label="Camera zoom">
            <button type="button" onClick={() => changeZoom(-0.08)} aria-label="Zoom camera in"><ZoomIn size={14} /></button>
            <span>{cameraZoom.toFixed(2)}×</span>
            <button type="button" onClick={() => changeZoom(0.08)} aria-label="Zoom camera out"><ZoomOut size={14} /></button>
          </div>
          <button type="button" className="camera-toggle" onClick={() => setCameraStyle((value) => value === "BROADCAST" ? "TACTICAL" : "BROADCAST")}>
            <Crosshair size={15} /><span>{cameraStyle}</span>
          </button>
          <span className="mode-caption"><span />{snapshot.mode === "PENALTIES" ? "SHOOTOUT" : snapshot.mode} <i>/</i> 90:00</span>
        </div>
      </motion.footer>

      <TouchControls press={press} release={release} penalties={snapshot.mode === "PENALTIES"} />

      <AnimatePresence>
        {panel && (
          <>
            <motion.div className="panel-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={resumeMatch} />
            <motion.aside
              key={panel}
              className="match-panel"
              initial={{ x: -26, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
              aria-label={`${panel.toLowerCase()} panel`}
            >
              <div className="panel-topline">
                <div className="panel-brand"><div className="brand-emblem mini"><span>N</span><i /></div><span>NOVA <i>/</i> MATCH CENTRE</span></div>
                <button type="button" className="panel-close" onClick={resumeMatch} aria-label="Close menu"><X size={19} /></button>
              </div>

              {panel === "MENU" && (
                <div className="panel-content menu-content">
                  <PanelHeading eyebrow={snapshot.finished ? "FULL TIME" : "MATCH PAUSED"} title={snapshot.finished ? "That is the match." : "Your game. Your call."} description={snapshot.finished ? `${home.name} ${snapshot.score[0]} - ${snapshot.score[1]} ${away.name}` : "The stadium is waiting. Pick up exactly where you left it."} />
                  <button type="button" className="primary-action" onClick={resumeMatch}><Play size={17} fill="currentColor" /><span>{snapshot.finished ? "BACK TO THE MATCH" : "RESUME MATCH"}</span><ChevronRight size={18} /></button>
                  <div className="menu-list">
                    <button type="button" onClick={() => { setSelectedMode(snapshot.mode); showPanel("MODES"); }}><LayoutGrid size={18} /><span><b>Game modes</b><small>Kick off, career, tournament and more</small></span><ChevronRight size={17} /></button>
                    <button type="button" onClick={() => showPanel("SQUAD")}><Users size={18} /><span><b>Team management</b><small>Formation, roles and starting XI</small></span><ChevronRight size={17} /></button>
                    <button type="button" onClick={() => showPanel("SETTINGS")}><Settings2 size={18} /><span><b>Match settings</b><small>Camera, motion sensors and graphics</small></span><ChevronRight size={17} /></button>
                    <a className="menu-download" href="/NOVA-Field-26-arm64.apk" download><Smartphone size={18} /><span><b>Android release</b><small>ARM64 signed APK · direct download</small></span><Download size={17} /></a>
                  </div>
                  <div className="panel-footnote"><span>ESC</span> TO RETURN TO THE MATCH <i>•</i> AUTOSAVE ON</div>
                </div>
              )}

              {panel === "MODES" && (
                <div className="panel-content modes-content">
                  <PanelHeading eyebrow="CHOOSE YOUR GAME" title="Set the occasion." description="From a single fixture to the final kick. The pitch is yours." />
                  <div className="mode-list">
                    {MODE_OPTIONS.map(({ mode, title, description, icon: Icon }) => (
                      <button key={mode} type="button" className={`mode-option${selectedMode === mode ? " is-selected" : ""}`} onClick={() => setSelectedMode(mode)}>
                        <span className="mode-icon"><Icon size={18} /></span>
                        <span className="mode-copy"><b>{title}</b><small>{description}</small></span>
                        <span className="mode-check">{selectedMode === mode ? <Check size={15} /> : <ChevronRight size={16} />}</span>
                      </button>
                    ))}
                  </div>
                  <div className="team-pickers">
                    <TeamSelect label="HOME CLUB" value={homeId} onChange={setHomeId} />
                    <div className="versus-mark">VS</div>
                    <TeamSelect label="AWAY CLUB" value={awayId} onChange={setAwayId} />
                  </div>
                  <button type="button" className="primary-action" onClick={startMatch}><Play size={17} fill="currentColor" /><span>START {selectedMode === "PENALTIES" ? "SHOOTOUT" : "MATCH"}</span><ChevronRight size={18} /></button>
                  <div className="panel-footnote">{activeMode.title.toUpperCase()} <i>•</i> NOVA ARENA <i>•</i> {timeOfDay}</div>
                </div>
              )}

              {panel === "SQUAD" && (
                <div className="panel-content squad-content">
                  <PanelHeading eyebrow={`${home.name.toUpperCase()} / STARTING XI`} title="Shape the side." description="Choose a formation or select a player to take control." />
                  <div className="formation-tabs" aria-label="Choose formation">
                    {FORMATIONS.map((formation) => (
                      <button key={formation} type="button" className={matchRef.current.formation === formation ? "is-active" : ""} onClick={() => changeFormation(formation)}>{formation}{matchRef.current.formation === formation && <i />}</button>
                    ))}
                  </div>
                  <div className="lineup-heading"><span>PLAYER</span><span>ROLE</span><span>FIT</span></div>
                  <div className="lineup-list">
                    {matchRef.current.players.filter((player) => player.team === 0).map((player) => (
                      <button key={player.id} type="button" className={`lineup-player${snapshot.selectedId === player.id ? " lineup-player-active" : ""}`} onClick={() => selectPlayer(player.id)}>
                        <span className="lineup-number">{String(player.number).padStart(2, "0")}</span>
                        <span className="lineup-name">{player.name}</span>
                        <span className="lineup-role">{player.role}</span>
                        <span className="fit-meter"><i style={{ width: `${player.stamina}%` }} /></span>
                      </button>
                    ))}
                  </div>
                  <button type="button" className="secondary-action" onClick={resumeMatch}><span>BACK TO MATCH</span><ChevronRight size={17} /></button>
                </div>
              )}

              {panel === "SETTINGS" && (
                <div className="panel-content settings-content">
                  <PanelHeading eyebrow="MATCH SETTINGS" title="Make it yours." description="Camera, motion controls and performance. Everything applies instantly." />

                  <div className="setting-section setting-first">
                    <div className="setting-title"><span>CAMERA</span><small>{cameraStyle === "BROADCAST" ? "TOUCHLINE CHASE" : "HIGH WIDE"}</small></div>
                    <div className="segmented-control">
                      <button type="button" className={cameraStyle === "BROADCAST" ? "selected" : ""} onClick={() => setCameraStyle("BROADCAST")}><Crosshair size={15} />Broadcast</button>
                      <button type="button" className={cameraStyle === "TACTICAL" ? "selected" : ""} onClick={() => setCameraStyle("TACTICAL")}><LayoutGrid size={15} />Tactical</button>
                    </div>
                    <div className="range-heading"><span>Zoom</span><b>{cameraZoom.toFixed(2)}× · {Math.round((cameraStyle === "TACTICAL" ? 11.4 : 10.7) * (0.87 + cameraZoom * 0.13))}m high</b></div>
                    <div className="range-row">
                      <ZoomIn size={16} />
                      <input aria-label="Camera zoom" type="range" min="0.72" max="1.55" step="0.01" value={cameraZoom} onChange={(event) => setCameraZoom(Number(event.target.value))} />
                      <ZoomOut size={16} />
                    </div>
                    <p className="setting-help">Smooth follow camera, capped at a close broadcast distance. It never jumps to a distant view.</p>
                  </div>

                  <div className="setting-section">
                    <div className="setting-title"><span>PHONE GYROSCOPE</span><small>{gyro.enabled ? "SENSORS ACTIVE" : gyro.supported ? "READY" : "NOT SUPPORTED HERE"}</small></div>
                    <div className="gyro-status">
                      <span className={`gyro-beacon${gyro.enabled ? " active" : ""}`}><Compass size={16} /></span>
                      <div>
                        <b>{gyro.enabled ? "Camera follows your phone" : "Enable motion camera"}</b>
                        <small>{gyro.enabled ? "Turn slowly to look around the action. Gameplay axes stay fixed." : "Landscape supported. Requires motion sensor access."}</small>
                      </div>
                    </div>
                    <div className="gyro-actions">
                      {gyro.enabled ? (
                        <>
                          <button type="button" className="mini-action" onClick={gyro.calibrate}><RotateCcw size={14} />Recentre</button>
                          <button type="button" className="mini-action muted" onClick={gyro.disable}><X size={14} />Disable</button>
                        </>
                      ) : (
                        <button type="button" className="mini-action" onClick={() => void gyro.enable()} disabled={gyro.permission === "requesting" || !gyro.supported}>
                          {gyro.permission === "requesting" ? <LoaderCircle size={14} className="spin" /> : <Compass size={14} />}
                          {gyro.permission === "requesting" ? "Requesting access" : "Enable gyroscope"}
                        </button>
                      )}
                    </div>
                    <div className="range-heading"><span>Sensitivity</span><b>{gyroSensitivity.toFixed(2)}×</b></div>
                    <div className="range-row">
                      <span className="range-low">LOW</span>
                      <input aria-label="Gyroscope sensitivity" type="range" min="0.35" max="2" step="0.05" value={gyroSensitivity} onChange={(event) => setGyroSensitivity(Number(event.target.value))} />
                      <span className="range-high">HIGH</span>
                    </div>
                    {gyro.error && <p className="setting-warning">{gyro.error}</p>}
                  </div>

                  <div className="setting-section">
                    <div className="setting-title"><span>GRAPHICS</span><small>{quality === "PERFORMANCE" ? "MOBILE / STABLE FPS" : quality === "BALANCED" ? "ADAPTIVE DETAIL" : "FULL DETAIL"}</small></div>
                    <div className="segmented-control">
                      <button type="button" className={quality === "PERFORMANCE" ? "selected" : ""} onClick={() => setQuality("PERFORMANCE")}><Gauge size={15} />Fast</button>
                      <button type="button" className={quality === "BALANCED" ? "selected" : ""} onClick={() => setQuality("BALANCED")}><Activity size={15} />Balanced</button>
                      <button type="button" className={quality === "HIGH" ? "selected" : ""} onClick={() => setQuality("HIGH")}><Zap size={15} />High</button>
                    </div>
                    <p className="setting-help">Fast lowers resolution, crowd density, grass and effects for steadier Android frame rates. Fog is disabled at every setting.</p>
                  </div>

                  <div className="setting-section">
                    <div className="setting-title"><span>CONDITIONS</span><small>CLEAR, LONG-RANGE LIGHTING</small></div>
                    <div className="segmented-control two-options">
                      <button type="button" className={weather === "CLEAR" ? "selected" : ""} onClick={() => setWeather("CLEAR")}><Sun size={15} />Clear</button>
                      <button type="button" className={weather === "RAIN" ? "selected" : ""} onClick={() => setWeather("RAIN")}><CloudRain size={15} />Rain</button>
                    </div>
                    <div className="segmented-control three-way-spaced">
                      <button type="button" className={timeOfDay === "DAY" ? "selected" : ""} onClick={() => setTimeOfDay("DAY")}><Sun size={15} />Day</button>
                      <button type="button" className={timeOfDay === "DUSK" ? "selected" : ""} onClick={() => setTimeOfDay("DUSK")}><Activity size={15} />Dusk</button>
                      <button type="button" className={timeOfDay === "NIGHT" ? "selected" : ""} onClick={() => setTimeOfDay("NIGHT")}><Moon size={15} />Night</button>
                    </div>
                  </div>

                  <div className="setting-section">
                    <div className="setting-title"><span>OPPOSITION</span><small>AI MATCH INTENSITY</small></div>
                    <label className="select-setting">
                      <Shield size={16} />
                      <select value={difficulty} onChange={(event) => { const value = event.target.value as MatchState["difficulty"]; setDifficulty(value); matchRef.current.difficulty = value; }}>
                        <option value="CASUAL">Casual</option>
                        <option value="COMPETITIVE">Competitive</option>
                        <option value="WORLD CLASS">World Class</option>
                      </select>
                      <ChevronDown size={15} />
                    </label>
                  </div>

                  <a className="download-card" href="/NOVA-Field-26-arm64.apk" download>
                    <span className="download-icon"><Smartphone size={20} /></span>
                    <span><b>NOVA Field 26 for Android</b><small>Signed release APK · arm64-v8a · landscape</small></span>
                    <Download size={18} />
                  </a>

                  <button type="button" className="secondary-action settings-done" onClick={resumeMatch}><span>APPLY & RETURN</span><Check size={17} /></button>
                </div>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </main>
  );
}

export default App;