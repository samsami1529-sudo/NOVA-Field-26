SHADOW DYNASTY — GitHub Android package

WHAT THIS PACKAGE DOES
- Keeps the original browser game HTML intact at:
  shadow-dynasty-app/app/src/main/assets/index.html
- Wraps it in a simple Android WebView app.
- Includes a GitHub Actions workflow to build a debug APK.

UPLOAD TO YOUR EXISTING REPOSITORY
Repository: samsami1529-sudo/NOVA-Field-26

IMPORTANT:
Do not replace or delete the existing football-game files.
Upload the contents of this ZIP into the repository root, preserving folders:
  1) shadow-dynasty-app/
  2) .github/workflows/shadow-dynasty-android.yml

Then commit the changes to the main branch.

BUILD:
Open the repository's Actions tab.
Select "Build Shadow Dynasty APK".
Press "Run workflow" if it did not start automatically.
When the run finishes successfully, open that run's Artifacts section
and download "Shadow-Dynasty-APK". The APK inside is app-debug.apk.

NOTES:
- The Android app runs the game locally; it does not need a website URL.
- The app opens in landscape and uses hardware-accelerated WebView.
- This is a debug APK for testing, not a Play Store release/signing setup.
- The original game uses WebGL; actual performance depends on the phone's
  WebView/GPU support. The in-game LOW quality option may help on weaker phones.
